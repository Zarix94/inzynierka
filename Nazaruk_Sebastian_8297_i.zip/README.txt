System do Zarządzania Wirtualnym Magazynem do uruchomienia wymaga spełnienia następujących warunków odnośnie serwer hostingowego:
•	PHP wersja co najmniej 7.4.5
•	PostgreSQL wersja co najmniej 12.
Po spełnieniu powyższych wymagań należy wykonać kroki opisane w instrukcji poniżej:
1. Umieszczenie plików źródłowych dołączonych do pracy dyplomowej na serwerze PHP.
2. Pobranie i zainstalowanie narzędzia do zarządzania zależnościami w języku PHP: Composer (https://getcomposer.org/download/).
3. Poprzez wiersz poleceń przejść do katalogu zawierającego pliki źródłowe projektu i wykonując komendę „composer install". Spowoduje to pobranie wszystkich zależności projektu.
4. Za pomocą narzędzia do zarządzania bazą danych np. pgAdmin utworzyć nową bazę danych.
5. W głównym katalogu projektu znajduje się plik o nazwie „.env.example”. Należy zmienić jego nazwę na „.env”.
6. Otworzyć plik „.env” przy pomocy edytora tekstu. Edytując następujące pola: DB_CONNECTIOn, DB_HOST, DB_PORT, DB_DATABASE, DB_USERNAME, DB_PASSWORD. 
Należy wypełnić powyższe pola danymi pozwalającym aplikacji na połączenie się ze stworzoną w kroku 4. bazą danych. Ważnym jest wpisanie wartości „pgsql” w polu DB_CONNECTION. Po wypełnieniu danych należy zapisać plik. „.env”. 
7. Po skonfigurowaniu pliku .env w wierszu poleceń należy użyć komendy „php artisan key:generate”, która spowoduje wygenerowanie klucza aplikacji.
8. Następnie przy pomocy komendy „php artisan migrate” jeśli baza danych została poprawnie skonfigurowana w kroku 6. system wygeneruje bazę danych na podstawie migracji oraz utworzy wpisy w podstawowych tabelach bazy danych.
