<?php
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use Illuminate\Http\Request;
use App\Models\User;

/*
 * |--------------------------------------------------------------------------
 * | Web Routes
 * |--------------------------------------------------------------------------
 * |
 * | Here is where you can register web routes for your application. These
 * | routes are loaded by the RouteServiceProvider within a group which
 * | contains the "web" middleware group. Now create something great!
 * |
 */
function getView(string $viewName) {
  if (! Auth::check())
    return view('login');

  $user = User::getLoggedUser();

  switch ($viewName) {
    case 'warehouse':
      return view('warehouse', \App\Views\WarehouseView::generateView($viewName));
      break;
    case 'product':
      return view('product', \App\Views\ProductView::generateView($viewName));
      break;
    case 'address':
      return view('address', \App\Views\AddressView::generateView($viewName));
      break;
    case 'order':
      return view('order', \App\Views\OrderView::generateView($viewName));
    case 'dictionary':
      if ($user->isSystemAdmin())
        return view('dictionary', \App\Views\DictionaryView::generateView($viewName));
      else
        return view('client', \App\Views\ClientView::generateView($viewName));
      break;
    case 'user':
      if (! $user->isClientUser())
        return view('user', \App\Views\UserView::generateView($viewName));
      else
        return view('client', \App\Views\ClientView::generateView($viewName));
      break;
    case 'client':
      if ($user->isClientUser())
        return view('warehouse', \App\Views\WarehouseView::generateView($viewName));
      else
        return view('client', \App\Views\ClientView::generateView($viewName));
    default:
      break;
  }
}

Route::get('', function (Request $request) {
  return getView('client');
});

Route::get('login', function (Request $request) {
  return getView('client');
});

Route::get('/password-recovery', function (Request $request) {
  return view('password-recovery');
});

Route::get('/client', function (Request $request) {
  return getView('client');
});

Route::get('/warehouse', function (Request $request) {
  return getView('warehouse');
});

Route::get('/product', function (Request $request) {
  return getView('product');
});

Route::get('/address', function (Request $request) {
  return getView('address');
});

Route::get('/order', function (Request $request) {
  return getView('order');
});

Route::get('/report', function (Request $request) {
  return view('report');
});

Route::get('/dictionary', function (Request $request) {
  return getView('dictionary');
});

Route::get('/user', function (Request $request) {
  return getView('user');
});

Route::get('/logout', function (Request $request) {
  User::logout($request);

  return redirect('/');
});

Route::post('/login-user', 'App\Http\Controllers\UserController@login');

Route::post('/get-for-table-adapter', 'App\Http\Controllers\AdapterController@getTable');

Route::get('/test', 'App\Http\Controllers\Test@test');

Route::post('/save-object', 'App\Http\Controllers\ObjectController@save');

Route::post('/reset-object', 'App\Http\Controllers\ObjectController@reset');

Route::post('/get-object', 'App\Http\Controllers\ObjectController@get');

Route::post('/remove-object', 'App\Http\Controllers\ObjectController@remove');

Route::post('/assing-warehouse', 'App\Http\Controllers\ClientController@assignWarehouses');

Route::post('/assing-condition', 'App\Http\Controllers\ClientController@assignConditions');

Route::post('/assing-carrier', 'App\Http\Controllers\ClientController@assignCarriers');

Route::post('/realize-deliver', 'App\Http\Controllers\OrderController@realizeDeliver');

Route::post('/get-addres-data', 'App\Http\Controllers\OrderController@getAddress');

Route::post('set-password', 'App\Http\Controllers\UserController@setPassword');
