<?php
namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use App\Models\Status;

class StatusSeeder extends Seeder {

  /**
   * Run the database seeds.
   *
   * @return void
   */
  public function run() {
    DB::table('status')->insert([
      'code' => 'DELIVER_NEW',
      'name' => 'Nowa',
      'type' => '1'
    ]);

    $obj = Status::where('code', 'DELIVER_NEW')->take(1)->get();
    DB::table('status')->insert([
      'code' => 'DELIVER_IN_PROGRESS',
      'name' => 'W przygotowaniu',
      'status_after_id' => $obj[0]->getId(),
      'type' => '1'
    ]);

    $obj = Status::where('code', 'DELIVER_IN_PROGRESS')->take(1)->get();
    DB::table('status')->insert([
      'code' => 'DELIVER_IN_TRANSPORT',
      'name' => 'W transporcie',
      'status_after_id' => $obj[0]->getId(),
      'type' => '1'
    ]);

    $obj = Status::where('code', 'DELIVER_IN_TRANSPORT')->take(1)->get();
    DB::table('status')->insert([
      'code' => 'DELIVER_COMPLETE',
      'name' => 'Zakończona',
      'status_after_id' => $obj[0]->getId(),
      'type' => '1'
    ]);

    DB::table('status')->insert([
      'code' => 'ORDER_NEW',
      'name' => 'Nowa',
      'type' => '2'
    ]);

    $obj = Status::where('code', 'ORDER_NEW')->take(1)->get();
    DB::table('status')->insert([
      'code' => 'ORDER_IN_PROGRESS',
      'name' => 'W przygotowaniu',
      'status_after_id' => $obj[0]->getId(),
      'type' => '2'
    ]);

    $obj = Status::where('code', 'ORDER_IN_PROGRESS')->take(1)->get();
    DB::table('status')->insert([
      'code' => 'ORDER_IN_TRANSPORT',
      'name' => 'W transporcie',
      'status_after_id' => $obj[0]->getId(),
      'type' => '2'
    ]);

    $obj = Status::where('code', 'ORDER_IN_TRANSPORT')->take(1)->get();
    DB::table('status')->insert([
      'code' => 'ORDER_COMPLETE',
      'name' => 'Zakończona',
      'status_after_id' => $obj[0]->getId(),
      'type' => '2'
    ]);
  }
}
