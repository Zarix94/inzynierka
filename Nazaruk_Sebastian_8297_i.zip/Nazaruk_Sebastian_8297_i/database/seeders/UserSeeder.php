<?php
namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use App\Models\UserRole;

class UserSeeder extends Seeder {

  /**
   * Run the database seeds.
   *
   * @return void
   */
  public function run() {
    $role = UserRole::where('const_name', 'CLIENT_USER')->take(1)->get();

    DB::table('users')->insert([
      'login' => 'admin',
      'password' => '$2y$10$UTqrO/LYjF7czqXBbmaRHutjQBrWBX1sWk0rwOc5a1pPz2WsUTM7W',
      'email' => 'test',
      'role_id' => $role[0]->id
    ]);
  }
}
