<?php
namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class UserRoleSeeder extends Seeder {

  /**
   * Run the database seeds.
   *
   * @return void
   */
  public function run() {
    DB::table('user_role')->insert([
      'name' => 'Administrator Systemu',
      'const_name' => 'SYSTEM_ADMIN'
    ]);

    DB::table('user_role')->insert([
      'name' => 'Administrator Klienta',
      'const_name' => 'CLIENT_ADMIN'
    ]);

    DB::table('user_role')->insert([
      'name' => 'Użytkownik klienta',
      'const_name' => 'CLIENT_USER'
    ]);
  }
}
