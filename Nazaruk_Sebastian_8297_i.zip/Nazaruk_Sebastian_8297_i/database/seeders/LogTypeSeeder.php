<?php
namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class LogTypeSeeder extends Seeder {

  /**
   * Run the database seeds.
   *
   * @return void
   */
  public function run() {
    DB::table('log_type')->insert([
      'name' => 'Udane logowanie',
      'const_name' => 'AUTH_LOG_LOGIN_SUCCESS'
    ]);

    DB::table('log_type')->insert([
      'name' => 'Nieudane logowanie',
      'const_name' => 'AUTH_LOG_LOGIN_FAILED'
    ]);

    DB::table('log_type')->insert([
      'name' => 'Utworzenie obiektu',
      'const_name' => 'OBJECT_CREATE'
    ]);

    DB::table('log_type')->insert([
      'name' => 'Zapisanie obiektu',
      'const_name' => 'OBJECT_SAVE'
    ]);

    DB::table('log_type')->insert([
      'name' => 'Usunięcie obiektu',
      'const_name' => 'OBJECT_DELETE'
    ]);
  }
}
