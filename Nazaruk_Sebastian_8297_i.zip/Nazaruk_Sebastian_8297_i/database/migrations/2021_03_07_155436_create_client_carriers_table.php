<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateClientCarriersTable extends Migration {

  /**
   * Run the migrations.
   *
   * @return void
   */
  public function up() {
    Schema::create('client_carrier', function (Blueprint $table) {
      $table->integer('client_id')->unsignedBigInteger();
      $table->integer('carrier_id')->unsignedBigInteger();

      $table->unique([
        'client_id',
        'carrier_id'
      ]);

      $table->foreign('client_id')
        ->references('id')
        ->on('client')
        ->onDelete('cascade')
        ->onUpdate('cascade');
      $table->foreign('carrier_id')
        ->references('id')
        ->on('carrier')
        ->onDelete('cascade')
        ->onUpdate('cascade');
    });
  }

  /**
   * Reverse the migrations.
   *
   * @return void
   */
  public function down() {
    Schema::dropIfExists('client_carrier');
  }
}
