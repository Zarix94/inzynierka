<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDeliverLinesTable extends Migration {

  /**
   * Run the migrations.
   *
   * @return void
   */
  public function up() {
    Schema::create('deliver_line', function (Blueprint $table) {
      $table->id();
      $table->timestamps();
      $table->softDeletes();

      $table->integer('quantity');
      $table->integer('document_id')->unsignedBigInteger();
      $table->unsignedBigInteger('condition_id');
      $table->unsignedBigInteger('product_id');

      $table->foreign('document_id')
        ->references('id')
        ->on('deliver_order')
        ->onDelete('cascade')
        ->onUpdate('cascade');

      $table->foreign('product_id')
        ->references('id')
        ->on('product');

      $table->foreign('condition_id')
        ->references('id')
        ->on('sku_condition');
    });
  }

  /**
   * Reverse the migrations.
   *
   * @return void
   */
  public function down() {
    // Schema::dropIfExists('deliver_line');
  }
}
