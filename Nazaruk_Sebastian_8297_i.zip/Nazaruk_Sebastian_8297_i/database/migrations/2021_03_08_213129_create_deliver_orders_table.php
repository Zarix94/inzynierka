<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDeliverOrdersTable extends Migration {

  /**
   * Run the migrations.
   *
   * @return void
   */
  public function up() {
    Schema::create('deliver_order', function (Blueprint $table) {
      $table->id();
      $table->timestamps();
      $table->timestamp('order_date');
      $table->integer('carrier_id')->unsignedBigInteger();
      $table->integer('warehouse_id')->unsignedBigInteger();
      $table->integer('country_id')
        ->unsignedBigInteger()
        ->nullable();

      $table->integer('client_id')->unsignedBigInteger();
      $table->integer('status_id')->unsignedBigInteger();
      $table->string('contractor_name')->nullable();
      $table->string('city')->nullable();
      $table->string('address')->nullable();
      $table->string('postcode')->nullable();

      $table->foreign('carrier_id')
        ->references('id')
        ->on('carrier')
        ->onDelete('cascade')
        ->onUpdate('cascade');

      $table->foreign('warehouse_id')
        ->references('id')
        ->on('warehouse')
        ->onDelete('cascade')
        ->onUpdate('cascade');

      $table->foreign('country_id')
        ->references('id')
        ->on('country');

      $table->foreign('client_id')
        ->references('id')
        ->on('client')
        ->onDelete('cascade')
        ->onUpdate('cascade');

      $table->foreign('status_id')
        ->references('id')
        ->on('status')
        ->onDelete('cascade')
        ->onUpdate('cascade');
      $table->softDeletes();
    });
  }

  /**
   * Reverse the migrations.
   *
   * @return void
   */
  public function down() {
    Schema::dropIfExists('deliver_status_history');
    Schema::dropIfExists('deliver_line');
    Schema::dropIfExists('deliver_order');
  }
}
