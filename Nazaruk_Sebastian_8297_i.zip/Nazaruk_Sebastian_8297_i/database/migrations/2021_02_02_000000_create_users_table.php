<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use App\Models\UserRole;
use Illuminate\Support\Facades\Artisan;

class CreateUsersTable extends Migration {

  /**
   * Run the migrations.
   *
   * @return void
   */
  public function up() {
    Schema::create('users', function (Blueprint $table) {
      $table->id();
      $table->string('login')->unique();
      $table->string('email')->unique();
      $table->string('password');
      $table->string('first_name')->nullable();
      $table->string('last_name')->nullable();
      $table->rememberToken();
      $table->timestamps();
      $table->softDeletes();
      $table->timestamp('last_login')->nullable();
      $table->timestamp('last_bad_login')->nullable();
      $table->unsignedBigInteger('client_id')->nullable();
      $table->foreign('client_id')
        ->references('id')
        ->on('client');

      $role = UserRole::where('const_name', 'CLIENT_USER')->take(1)->get();

      $table->unsignedBigInteger('role_id')->default($role[0]->id);
      $table->foreign('role_id')
        ->references('id')
        ->on('user_role');
    });
    Artisan::call('db:seed', array(
      '--class' => 'UserSeeder'
    ));
  }

  /**
   * Reverse the migrations.
   *
   * @return void
   */
  public function down() {
    Schema::dropIfExists('users');
  }
}
