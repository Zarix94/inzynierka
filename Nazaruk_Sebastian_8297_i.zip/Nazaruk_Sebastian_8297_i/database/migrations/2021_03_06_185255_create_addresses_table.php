<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAddressesTable extends Migration {

  /**
   * Run the migrations.
   *
   * @return void
   */
  public function up() {
    Schema::create('address', function (Blueprint $table) {
      $table->id();
      $table->string('code')->unique();
      $table->string('name');

      $table->unsignedBigInteger('client_id');
      $table->foreign('client_id')
        ->references('id')
        ->on('client');

      $table->unsignedBigInteger('country_id');
      $table->foreign('country_id')
        ->references('id')
        ->on('country');

      $table->string('city');
      $table->string('address');
      $table->string('postcode');
      $table->string('description')->nullable();
      $table->string('contact_email')->nullable();
      $table->string('contact_number')->nullable();

      $table->timestamps();
      $table->softDeletes();
    });
  }

  /**
   * Reverse the migrations.
   *
   * @return void
   */
  public function down() {
    Schema::dropIfExists('address');
  }
}
