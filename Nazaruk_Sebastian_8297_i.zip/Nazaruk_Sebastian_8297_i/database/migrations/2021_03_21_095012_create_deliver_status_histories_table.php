<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDeliverStatusHistoriesTable extends Migration {

  /**
   * Run the migrations.
   *
   * @return void
   */
  public function up() {
    Schema::create('deliver_status_history', function (Blueprint $table) {
      $table->id();
      $table->timestamps();
      $table->timestamp('change_time');
      $table->softDeletes();
      $table->integer('status_id')->unsignedBigInteger();
      $table->integer('document_id')->unsignedBigInteger();

      $table->foreign('document_id')
        ->references('id')
        ->on('deliver_order')
        ->onDelete('cascade')
        ->onUpdate('cascade');

      $table->foreign('status_id')
        ->references('id')
        ->on('status')
        ->onDelete('cascade')
        ->onUpdate('cascade');
    });
  }

  /**
   * Reverse the migrations.
   *
   * @return void
   */
  public function down() {
    // Schema::dropIfExists('deliver_status_histories');
  }
}
