<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateClientTable extends Migration {

  /**
   * Run the migrations.
   *
   * @return void
   */
  public function up() {
    Schema::create('client', function (Blueprint $table) {
      $table->id();
      $table->string('code')->unique();
      $table->string('name');
      $table->string('nip')->unique();
      $table->string('contact_email')->nullable();
      $table->string('contact_number');
      $table->unsignedBigInteger('country_id');
      $table->foreign('country_id')
        ->references('id')
        ->on('country');
      $table->string('city')->nullable();
      $table->string('address')->nullable();
      $table->string('postcode')->nullable();
      $table->string('description')->nullable();

      $table->softDeletes();
      $table->timestamps();
    });
  }

  /**
   * Reverse the migrations.
   *
   * @return void
   */
  public function down() {
    Schema::dropIfExists('client');
  }
}
