<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAuthLogsTable extends Migration {

  /**
   * Run the migrations.
   *
   * @return void
   */
  public function up() {
    Schema::create('auth_log', function (Blueprint $table) {
      $table->id();
      $table->timestamps();
      $table->timestamp('log_timestamp');
      $table->unsignedBigInteger('user_id');
      $table->unsignedBigInteger('log_type_id');
      $table->softDeletes();

      $table->foreign('user_id')
        ->references('id')
        ->on('users');

      $table->foreign('log_type_id')
        ->references('id')
        ->on('log_type');
    });
  }

  /**
   * Reverse the migrations.
   *
   * @return void
   */
  public function down() {
    Schema::dropIfExists('auth_log');
  }
}
