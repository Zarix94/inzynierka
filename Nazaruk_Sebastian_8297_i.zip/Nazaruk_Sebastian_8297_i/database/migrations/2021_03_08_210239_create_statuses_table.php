<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Artisan;

class CreateStatusesTable extends Migration {

  /**
   * Run the migrations.
   *
   * @return void
   */
  public function up() {
    Schema::create('status', function (Blueprint $table) {
      $table->id();
      $table->timestamps();
      $table->softDeletes();
      $table->integer('type');
      $table->string('name');
      $table->string('code')->unique();
      $table->integer('status_after_id')
        ->nullable()
        ->unsignedBigInteger();
      $table->foreign('status_after_id')
        ->references('id')
        ->on('status')
        ->onDelete('cascade')
        ->onUpdate('cascade');
    });

    Artisan::call('db:seed', array(
      '--class' => 'StatusSeeder'
    ));
  }

  /**
   * Reverse the migrations.
   *
   * @return void
   */
  public function down() {
    Schema::dropIfExists('status');
  }
}
