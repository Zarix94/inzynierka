<?php
namespace App\HtmlGenerator\Inputs;

use App\HtmlGenerator\Generator;

class Input extends Generator {

  protected $dataId = '';

  protected $type = 'text';

  protected $required = false;

  public function __construct(string $elementId, string $label, string $dataId = '', bool $required = false) {
    $this->setElementId($elementId);
    $this->setLabel($label);
    $this->dataId = $dataId;
    $this->required = $required;
  }

  public function setType(string $type): void {
    $this->type = $type;
  }

  public function generateHtml(): string {
    $html = '';
    $html .= '  <div class="form-group  mb-1">';
    $html .= '    <div style="display: flex">';
    $html .= '      <label style="width: 250px; padding: 0.375rem 0.75rem;" for="' . $this->getElementId() . '">' . $this->getLabel() . '</label>';

    $class = 'form-control';
    if ($this->required === true)
      $class .= ' required-field';

    $html .= '      <input id="' . $this->getElementId() . '" ';
    $html .= '        type="' . $this->type . '" ';
    $html .= '        class="' . $class . '"  placeholder="' . $this->getLabel() . '"';
    if ($this->dataId != '')
      $html .= '      data-id="' . $this->dataId . '"';
    $html .= '      data-toggle="tooltip" title="">';
    $html .= '    </div>';
    $html .= '    <div id="' . $this->getElementId() . '-invalid-msg" class="invalid-feedback">.</div>';
    $html .= '  </div>';
    return $html;
  }
}

