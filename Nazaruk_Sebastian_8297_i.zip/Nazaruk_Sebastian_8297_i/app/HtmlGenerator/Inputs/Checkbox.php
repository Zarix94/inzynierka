<?php
namespace App\HtmlGenerator\Inputs;

use App\HtmlGenerator\Generator;

class Checkbox extends Generator {

  private $dataId = '';

  private $required = false;

  private $withLabel = true;

  private $value = 'off';

  public function __construct(string $elementId, string $label, string $dataId = '', bool $required = false) {
    $this->setElementId($elementId);
    $this->setLabel($label);
    $this->dataId = $dataId;
    $this->required = $required;
  }

  public function setWithLabel(bool $withLabel): void {
    $this->withLabel = $withLabel;
  }

  public function setValue(string $value): void {
    $this->value = $value;
  }

  public function generateHtml(): string {
    $html = '';
    $html .= '  <div class="form-group  mb-1">';
    $html .= '    <div style="display: flex">';
    if ($this->withLabel === true)
      $html .= '      <label style="width: 250px; padding: 0.375rem 0.75rem;" for="' . $this->getElementId() . '">' . $this->getLabel() . '</label>';

    $class = 'form-control form-check-input';
    $class .= ' ' . $this->getClass();
    if ($this->required === true)
      $class .= ' required-field';

    $html .= '      <input id="' . $this->getElementId() . '" type="checkbox" class="' . $class . '"  placeholder="' . $this->getLabel() . '"';
    if ($this->dataId != '')
      $html .= '      data-id="' . $this->dataId . '"';

    if ($this->value == 'on')
      $html .= '      checked ';
    $html .= '      data-toggle="tooltip" title="" ">';
    $html .= '    </div>';
    $html .= '    <div id="' . $this->getElementId() . '-invalid-msg" class="invalid-feedback">.</div>';
    $html .= '  </div>';
    return $html;
  }
}

