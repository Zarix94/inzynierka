<?php
namespace App\HtmlGenerator\Inputs;

use App\HtmlGenerator\Generator;

class Button extends Generator {

  const BT_NORMAL = 'btn-primary';

  const BT_RED = 'btn-danger';

  const BT_GREEN = 'btn-success';

  public function __construct(string $elementId, string $label, string $type = self::BT_NORMAL) {
    $this->setElementId($elementId);
    $this->setLabel($label);
    $this->setType($type);
  }

  public function setType(string $type) {
    $this->type = $type;
  }

  public function generateHtml(): string {
    $html = '';
    $html .= '<button id="' . $this->getElementId() . '" type="button" style="width: 100px; color: #fff; margin: 5px;" class="btn ' . $this->type . '">' . $this->getLabel() . '</button>';
    return $html;
  }
}