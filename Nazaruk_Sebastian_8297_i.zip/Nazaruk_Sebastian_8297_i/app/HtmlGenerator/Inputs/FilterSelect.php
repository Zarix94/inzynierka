<?php
namespace App\HtmlGenerator\Inputs;

class FilterSelect extends Select {

  public function generateHtml(): string {
    $html = '';
    $html .= '  <div class="form-group  mb-1">';
    $html .= '    <div>';
    $html .= '      <label style="width: 100%; padding: 0.375rem 0.75rem;" for="' . $this->getElementId() . '">' . $this->getLabel() . '</label>';

    $class = 'form-control filter-select';
    if ($this->required === true)
      $class .= ' required-field';

    $html .= '      <select id="' . $this->getElementId() . '" class="' . $class . '"';
    if ($this->dataId != '')
      $html .= '      data-id="' . $this->dataId . '"';
    $html .= '        data-toggle="tooltip" title="">';
    $html .= '        <option value="0" >' . $this->prepend . '</option>';

    if ($this->adapter !== null)
      $this->getData();

    foreach ($this->options as $option)
      $html .= '      <option value="' . $option->id . '" >' . $option->name . '</option>';
    $html .= '       </select>';
    $html .= '    </div>';
    $html .= '    <div id="' . $this->getElementId() . '-invalid-msg" class="invalid-feedback">.</div>';
    $html .= '  </div>';
    return $html;
  }
}

