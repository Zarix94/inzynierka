<?php
namespace App\HtmlGenerator\Inputs;

use App\HtmlGenerator\Generator;

class Textarea extends Generator {

  private $dataId = '';

  public function __construct(string $elementId, string $label, string $dataId = '') {
    $this->setElementId($elementId);
    $this->setLabel($label);
    $this->dataId = $dataId;
  }

  public function generateHtml(): string {
    $html = '';
    $html .= '  <div class="form-group  mb-1">';
    $html .= '    <div style="display: flex">';
    $html .= '      <label style="width: 250px; padding: 0.375rem 0.75rem;" for="' . $this->getElementId() . '">' . $this->getLabel() . '</label>';
    $html .= '      <textarea id="' . $this->getElementId() . '" class="form-control" rows="3" placeholder="' . $this->getLabel() . '"';
    if ($this->dataId != '')
      $html .= '      data-id="' . $this->dataId . '"';
    $html .= '      ></textarea>';
    $html .= '    </div>';
    $html .= '    <div id="' . $this->getElementId() . '-invalid-msg" class="invalid-feedback">.</div>';
    $html .= '  </div>';
    return $html;
  }
}