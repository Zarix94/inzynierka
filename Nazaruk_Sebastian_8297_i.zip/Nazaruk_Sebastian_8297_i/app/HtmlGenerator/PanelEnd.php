<?php
namespace App\HtmlGenerator;

class PanelEnd extends Generator {

  public function generateHtml(): string {
    return '</div>';
  }
}