<?php
namespace App\HtmlGenerator;

abstract class Generator {

  private $elementId = '';

  private $label = '';

  private $class = '';

  public function setElementId(string $elementId): void {
    $this->elementId = $elementId;
  }

  public function getElementId(): string {
    return $this->elementId;
  }

  public function setLabel(string $label): void {
    $this->label = $label;
  }

  public function getLabel(): string {
    return $this->label;
  }

  public function setClass(string $class): void {
    $this->class = $class;
  }

  public function getClass(): string {
    return $this->class;
  }

  abstract public function generateHtml(): string;
}