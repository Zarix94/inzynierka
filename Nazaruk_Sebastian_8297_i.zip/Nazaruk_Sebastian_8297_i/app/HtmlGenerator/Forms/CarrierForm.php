<?php
namespace App\HtmlGenerator\Forms;

use App\HtmlGenerator\Inputs\Input;
use App\HtmlGenerator\Inputs\Textarea;
use App\HtmlGenerator\PanelStart;
use App\HtmlGenerator\PanelEnd;
use App\HtmlGenerator\Inputs\Select;
use App\Models\Country;
use App\Adapter\SAdapter\CountrySAdapter;

class CarrierForm extends FormGenerator {

  protected function onPreGenerate() {
    $this->setElementId('carrier-form');
    $this->setDisplay('flex');
    $this->setInputs();
  }

  private function setInputs() {
    $this->addInput(new PanelStart());
    $this->addInput(new Input('itCarrierCode', 'Kod', 'code', true));
    $this->addInput(new Input('itCarrierName', 'Nazwa', 'name', true));
    $this->addInput(new PanelEnd());
  }
}