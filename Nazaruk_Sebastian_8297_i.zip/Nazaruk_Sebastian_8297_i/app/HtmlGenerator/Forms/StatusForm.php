<?php
namespace App\HtmlGenerator\Forms;

use App\HtmlGenerator\Inputs\Input;
use App\HtmlGenerator\Inputs\Textarea;
use App\HtmlGenerator\PanelStart;
use App\HtmlGenerator\PanelEnd;
use App\HtmlGenerator\Inputs\Select;
use App\Models\Country;
use App\Adapter\SAdapter\CountrySAdapter;
use App\Adapter\SAdapter\StatusSAdapter;

class StatusForm extends FormGenerator {

  protected function onPreGenerate() {
    $this->setElementId('status-form');
    $this->setDisplay('flex');
    $this->setInputs();
  }

  private function setInputs() {
    $this->addInput(new PanelStart());
    $this->addInput(new Input('itStatusCode', 'Kod', 'code', true));

    $this->addInput(new Input('itStatusName', 'Nazwa', 'name', true));

    $typeSelect = new Select('itStatusType', 'Typ', 'type', true);
    $options = [];

    $option = new \stdClass();
    $option->id = 1;
    $option->name = 'Awizacje dostaw';
    $options[] = $option;

    $option = new \stdClass();
    $option->id = 2;
    $option->name = 'Awizacje wysyłki';
    $options[] = $option;

    $typeSelect->setOptions($options);
    $this->addInput($typeSelect);

    $statusSelect = new Select('itStatusAfter', 'Następny status', 'status_after_id');
    $statusSelect->setAdapter(new StatusSAdapter());
    $statusSelect->setPrepend('Brak');
    $this->addInput($statusSelect);

    $this->addInput(new PanelEnd());
  }
}