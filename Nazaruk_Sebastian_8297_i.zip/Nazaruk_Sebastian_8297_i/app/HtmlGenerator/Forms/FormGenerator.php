<?php
namespace App\HtmlGenerator\Forms;

use App\HtmlGenerator\Generator;

class FormGenerator extends Generator {

  private $display = 'block';

  private $inputs = [];

  protected function onPreGenerate() {}

  public function __construct() {
    $this->onPreGenerate();
  }

  public function addInput(Generator $input) {
    $this->inputs[] = $input;
  }

  public function setDisplay(string $display) {
    $this->display = $display;
  }

  public function generateHtml(): string {
    $html = '';
    $html .= '<form id="' . $this->getElementId() . '" class="col-3" style="width: fit-content; padding: 10px; background: #fff; display:' . $this->display . '">';
    foreach ($this->inputs as $input)
      $html .= $input->generateHtml();
    $html .= '</form>';

    return $html;
  }
}