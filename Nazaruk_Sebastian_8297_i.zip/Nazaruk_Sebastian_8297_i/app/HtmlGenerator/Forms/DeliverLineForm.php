<?php
namespace App\HtmlGenerator\Forms;

use App\HtmlGenerator\Inputs\Input;
use App\HtmlGenerator\Inputs\Textarea;
use App\HtmlGenerator\PanelStart;
use App\HtmlGenerator\PanelEnd;
use App\HtmlGenerator\Inputs\Select;
use App\Models\Country;
use App\Adapter\SAdapter\CountrySAdapter;
use App\Adapter\SAdapter\CarrierSAdapter;
use App\Adapter\SAdapter\WarehouseSAdapter;
use App\Adapter\SAdapter\SkuUnitSAdapter;
use App\Adapter\SAdapter\ProductSAdapter;
use App\Adapter\SAdapter\SkuConditionSAdapter;

class DeliverLineForm extends FormGenerator {

  protected function onPreGenerate() {
    $this->setElementId('deliver-line-form');
    $this->setDisplay('flex');
    $this->setInputs();
  }

  private function setInputs() {
    $this->addInput(new PanelStart());
    $selectProduct = new Select('itDeliverLineProduct', 'Produkt', 'product_id', true);
    $selectProduct->setAdapter(new ProductSAdapter());
    $this->addInput($selectProduct);

    $selectCondition = new Select('itDeliverLineCondition', 'Kondycja towaru', 'condition_id', true);
    $selectCondition->setAdapter(new SkuConditionSAdapter());
    $this->addInput($selectCondition);

    $quantityInput = new Input('itDeliverLineQuantity', 'Ilość', 'quantity', true);
    $quantityInput->setType('number');
    $this->addInput($quantityInput);

    $this->addInput(new PanelEnd());
  }
}