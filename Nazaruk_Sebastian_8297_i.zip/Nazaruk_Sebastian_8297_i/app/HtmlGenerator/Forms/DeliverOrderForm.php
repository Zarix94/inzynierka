<?php
namespace App\HtmlGenerator\Forms;

use App\HtmlGenerator\Inputs\Input;
use App\HtmlGenerator\Inputs\Textarea;
use App\HtmlGenerator\PanelStart;
use App\HtmlGenerator\PanelEnd;
use App\HtmlGenerator\Inputs\Select;
use App\Models\Country;
use App\Adapter\SAdapter\CountrySAdapter;
use App\Adapter\SAdapter\CarrierSAdapter;
use App\Adapter\SAdapter\WarehouseSAdapter;
use App\Models\Address;
use App\Adapter\SAdapter\AddressSAdapter;

class DeliverOrderForm extends FormGenerator {

  protected function onPreGenerate() {
    $this->setElementId('deliver-order-form');
    $this->setDisplay('flex');
    $this->setInputs();
  }

  private function setInputs() {
    $this->addInput(new PanelStart());
    $this->addInput(new Input('itOrderDate', 'Data dostawy', 'order_date', true));

    $select = new Select('itOrderWarehouse', 'Magazyn', 'warehouse_id', true);
    $select->setAdapter(new WarehouseSAdapter());
    $this->addInput($select);

    $select = new Select('itOrderCarrier', 'Przewoźnik', 'carrier_id', true);
    $select->setAdapter(new CarrierSAdapter());
    $this->addInput($select);

    $this->addInput(new PanelEnd());
    $this->addInput(new PanelStart());

    $select = new Select('itAddress', 'Adres');
    $select->setAdapter(new AddressSAdapter());
    $this->addInput($select);
    $select = new Select('itOrderCountry', 'Kraj', 'country_id');
    $select->setAdapter(new CountrySAdapter());
    $this->addInput($select);
    $this->addInput(new Input('itContractorName', 'Kontrahent', 'contractor_name'));
    $this->addInput(new Input('itOrderCity', 'Miasto', 'city'));
    $this->addInput(new Input('itOrderAddress', 'Adres', 'address'));
    $this->addInput(new Input('itOrderPostCode', 'Kod pocztowy', 'postcode'));
    $this->addInput(new PanelEnd());
  }
}