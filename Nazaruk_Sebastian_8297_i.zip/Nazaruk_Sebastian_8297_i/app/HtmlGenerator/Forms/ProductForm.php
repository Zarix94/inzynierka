<?php
namespace App\HtmlGenerator\Forms;

use App\HtmlGenerator\Inputs\Input;
use App\HtmlGenerator\PanelStart;
use App\HtmlGenerator\PanelEnd;
use App\HtmlGenerator\Inputs\Select;
use App\Models\Country;
use App\Adapter\SAdapter\ClientSAdapter;
use App\Adapter\SAdapter\SkuUnitSAdapter;
use App\Models\User;

class ProductForm extends FormGenerator {

  protected function onPreGenerate() {
    $this->setElementId('product-form');
    $this->setDisplay('flex');
    $this->setInputs();
  }

  private function setInputs() {
    $this->addInput(new PanelStart());
    $this->addInput(new Input('itProductCode', 'Kod', 'code', true));
    $this->addInput(new Input('itProductName', 'Nazwa', 'name', true));

    $selectUnit = new Select('itUnit', 'Jednostka składowania', 'unit_id', true);
    $selectUnit->setAdapter(new SkuUnitSAdapter());
    $this->addInput($selectUnit);

    $user = User::getLoggedUser();
    if ($user->isSystemAdmin()) {
      $selectClient = new Select('itClient', 'Klient', 'client_id', true);
      $selectClient->setAdapter(new ClientSAdapter());
      $this->addInput($selectClient);
    }

    $this->addInput(new PanelEnd());
  }
}