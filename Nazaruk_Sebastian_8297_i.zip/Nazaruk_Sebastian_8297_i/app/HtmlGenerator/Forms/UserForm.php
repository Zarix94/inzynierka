<?php
namespace App\HtmlGenerator\Forms;

use App\HtmlGenerator\Inputs\Input;
use App\HtmlGenerator\PanelStart;
use App\HtmlGenerator\PanelEnd;
use App\HtmlGenerator\Inputs\Select;
use App\Adapter\SAdapter\RoleSAdapter;
use App\Adapter\SAdapter\ClientSAdapter;
use App\Models\User;

class UserForm extends FormGenerator {

  protected function onPreGenerate() {
    $this->setElementId('user-form');
    $this->setDisplay('flex');

    $this->setInputs();
  }

  private function setInputs() {
    $this->addInput(new PanelStart());
    $roleSelect = new Select('itRole', 'Rola', 'role_id', true);
    $roleSelect->setAdapter(new RoleSAdapter());
    $this->addInput($roleSelect);

    $user = User::getLoggedUser();
    if ($user->isSystemAdmin()) {
      $clientSelect = new Select('itClient', 'Klient', 'client_id');
      $clientSelect->setAdapter(new ClientSAdapter());
      $this->addInput($clientSelect);
    }

    $this->addInput(new Input('itLogin', 'Login', 'login', true));
    $this->addInput(new Input('itEmail', 'Adres E-mail', 'email', true));

    $this->addInput(new Input('itFirstName', 'Imię', 'first_name'));
    $this->addInput(new Input('itLastName', 'Nazwisko', 'last_name'));
    $this->addInput(new PanelEnd());
  }
}