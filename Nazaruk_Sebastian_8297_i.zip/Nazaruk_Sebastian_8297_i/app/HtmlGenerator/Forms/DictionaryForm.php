<?php
namespace App\HtmlGenerator\Forms;

use App\HtmlGenerator\Inputs\Input;
use App\HtmlGenerator\Inputs\Textarea;
use App\HtmlGenerator\PanelStart;
use App\HtmlGenerator\PanelEnd;
use App\HtmlGenerator\Inputs\Select;
use App\Models\Country;
use App\Adapter\SAdapter\CountrySAdapter;

class DictionaryForm extends FormGenerator {

  private $modelName = '';

  private $formId = '';

  public function __construct(string $modelName, string $formId) {
    $this->modelName = $modelName;
    $this->formId = $formId;
    parent::__construct();
  }

  protected function onPreGenerate() {
    $this->setElementId($this->formId);
    $this->setDisplay('flex');
    $this->setInputs();
  }

  private function setInputs() {
    $this->addInput(new PanelStart());
    $this->addInput(new Input('it' . $this->modelName . 'Code', 'Kod', 'code', true));
    $this->addInput(new Input('it' . $this->modelName . 'Name', 'Nazwa', 'name', true));
    $this->addInput(new PanelEnd());
  }
}