<?php
namespace App\HtmlGenerator\Forms;

use App\HtmlGenerator\Inputs\Input;
use App\HtmlGenerator\Inputs\Textarea;
use App\HtmlGenerator\PanelStart;
use App\HtmlGenerator\PanelEnd;
use App\HtmlGenerator\Inputs\Select;
use App\Models\Country;
use App\Adapter\SAdapter\CountrySAdapter;
use App\Adapter\SAdapter\ClientSAdapter;
use App\Models\User;
use App\HtmlGenerator\Inputs\Button;

class ChangePasswordForm extends FormGenerator {

  protected function onPreGenerate() {
    $this->setElementId('change-password-form');
    $this->setDisplay('flex');
    $this->setInputs();
  }

  private function setInputs() {
    $user = User::getLoggedUser();
    if (! $user->isClientUser()) {
      $panel = new PanelStart();
      $panel->setWidth('100%');
      $this->addInput($panel);
      $this->addInput($panel);
      $this->addInput(new Input('itPassword', 'Hasło', 'password', true));
      $this->addInput(new PanelEnd());
      $panel = new PanelStart();
      $panel->setWidth('100%');
      $this->addInput(new Button('btSetPassword', 'Ustaw hasło', Button::BT_GREEN));
      $this->addInput(new Button('btCloseDialog', 'Zamknij'));

      $this->addInput(new PanelEnd());
    }

    $this->addInput(new PanelEnd());
  }
}