<?php
namespace App\HtmlGenerator\Forms;

use App\HtmlGenerator\Inputs\Input;
use App\HtmlGenerator\Inputs\Textarea;
use App\HtmlGenerator\PanelStart;
use App\HtmlGenerator\PanelEnd;
use App\HtmlGenerator\Inputs\Select;
use App\Models\Country;
use App\Adapter\SAdapter\CountrySAdapter;
use App\Models\User;

class ClientForm extends FormGenerator {

  protected function onPreGenerate() {
    $this->setElementId('client-form');
    $this->setDisplay('flex');
    $this->setInputs();
  }

  private function setInputs() {
    $this->addInput(new PanelStart());
    $user = User::getLoggedUser();
    if ($user->isSystemAdmin()) {
      $this->addInput(new Input('itCode', 'Kod', 'code', true));
      $this->addInput(new Input('itName', 'Nazwa', 'name', true));
      $this->addInput(new Input('itNip', 'Nip', 'nip', true));
    }
    $this->addInput(new Input('itEmail', 'Adres e-mail', 'contact_email'));
    $this->addInput(new Input('itPhone', 'Numer kontaktowy', 'contact_number', true));
    $this->addInput(new Textarea('itDescription', 'Opis', 'description'));
    $this->addInput(new PanelEnd());

    $this->addInput(new PanelStart());
    $select = new Select('itCountry', 'Kraj', 'country_id', true);
    $select->setAdapter(new CountrySAdapter());
    $this->addInput($select);
    $this->addInput(new Input('itCity', 'Miasto', 'city'));
    $this->addInput(new Input('itAddress', 'Adres', 'address'));
    $this->addInput(new Input('itPostCode', 'Kod pocztowy', 'postcode'));
    $this->addInput(new PanelEnd());
  }
}