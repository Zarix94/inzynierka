<?php
namespace App\HtmlGenerator;

class PanelStart extends Generator {

  private $width = '500px';

  private $float = '';

  public function setWidth(string $width) {
    $this->width = $width;
  }

  public function setFloat(string $float) {
    $this->float = $float;
  }

  public function generateHtml(): string {
    $html = '';
    $html .= '<div style="';
    $html .= 'width: ' . $this->width . ';';
    if ($this->float != '')
      $html .= 'float: ' . $this->float . ';';
    $html .= '">';
    return $html;
  }
}