<?php
namespace App\HtmlGenerator\Component;

use App\HtmlGenerator\Forms\UserForm;
use App\HtmlGenerator\PanelStart;
use App\HtmlGenerator\PanelEnd;
use App\HtmlGenerator\Inputs\Button;

class UserData extends Component {

  protected function init() {
    $this->addElement(new UserForm());
    $panel = new PanelStart();
    $panel->setWidth('1000px');
    $this->addElement($panel);
    $this->addElement(new PanelEnd());
    $panel = new PanelStart();
    $panel->setWidth('100px');
    $panel->setFloat('right');
    $this->addElement($panel);
    $this->addElement(new Button('btSetPasswordDialog', 'Ustaw hasło', Button::BT_NORMAL));
    $this->addElement(new ActionButtons('', false));
    $this->addElement(new PanelEnd());
  }
}