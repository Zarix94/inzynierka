<?php
namespace App\HtmlGenerator\Component;

use App\HtmlGenerator\Generator;

abstract class Component extends Generator {

  private $elements = [];

  public function addElement(Generator $element) {
    $this->elements[] = $element;
  }

  abstract protected function init();

  public function generateHtml(): string {
    $this->init();
    $html = '';
    foreach ($this->elements as $element)
      $html .= $element->generateHtml();
    return $html;
  }

  public static function getComponent() {
    $className = get_called_class();

    $class = new $className();
    return $class->generateHtml();
  }
}