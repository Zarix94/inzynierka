<?php
namespace App\HtmlGenerator\Component;

use App\HtmlGenerator\PanelStart;
use App\HtmlGenerator\PanelEnd;
use App\HtmlGenerator\Forms\WarehouseForm;
use App\Models\User;

class WarehouseData extends Component {

  protected function init() {
    $this->addElement(new WarehouseForm());
    $panel = new PanelStart();
    $panel->setWidth('1000px');
    $this->addElement($panel);
    $this->addElement(new PanelEnd());

    $user = User::getLoggedUser();
    if ($user->isSystemAdmin())
      $this->addElement(new ActionButtons());
  }
}