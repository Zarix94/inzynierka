<?php
namespace App\HtmlGenerator\Component;

use App\HtmlGenerator\PanelStart;
use App\HtmlGenerator\PanelEnd;
use App\HtmlGenerator\Forms\CountryForm;
use App\HtmlGenerator\Forms\StatusForm;

class StatusData extends Component {

  protected function init() {
    $this->addElement(new StatusForm());
    $panel = new PanelStart();
    $panel->setWidth('1000px');
    $this->addElement($panel);
    $this->addElement(new PanelEnd());
    $this->addElement(new ActionButtons('Status'));
  }
}