<?php
namespace App\HtmlGenerator\Component;

use App\HtmlGenerator\Inputs\FilterInput;
use App\Adapter\SAdapter\CountrySAdapter;
use App\HtmlGenerator\Inputs\FilterSelect;

class ClientFilter extends Component {

  protected function init() {
    $this->addElement(new FilterInput('itCodeSearch', 'Kod', 'code'));
    $this->addElement(new FilterInput('itNameSearch', 'Nazwa', 'name'));
    $this->addElement(new FilterInput('itNipSearch', 'Nip', 'nip'));
    $this->addElement(new FilterInput('itEmailSearch', 'Adres e-mail', 'contact_email'));
    $this->addElement(new FilterInput('itPhoneSearch', 'Numer kontaktowy', 'contact_number'));
    $select = new FilterSelect('itCountrySearch', 'Kraj', 'country_id');
    $select->setAdapter(new CountrySAdapter());
    $this->addElement($select);
    $this->addElement(new FilterInput('itCitySearch', 'Miasto', 'city'));
    $this->addElement(new FilterInput('itAddressSearch', 'Adres', 'address'));
    $this->addElement(new FilterInput('itPostCodeSearch', 'Kod pocztowy', 'postcode'));
  }
}