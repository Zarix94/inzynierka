<?php
namespace App\HtmlGenerator\Component;

use App\HtmlGenerator\PanelStart;
use App\HtmlGenerator\PanelEnd;
use App\HtmlGenerator\Forms\WarehouseForm;
use App\HtmlGenerator\Forms\DeliverOrderForm;
use App\HtmlGenerator\Inputs\Button;
use App\HtmlGenerator\Forms\DeliverLineForm;

class DeliverLineData extends Component {

  protected function init() {
    $this->addElement(new DeliverLineForm());
    $panel = new PanelStart();
    $panel->setWidth('1000px');
    $this->addElement($panel);
    $this->addElement(new PanelEnd());
    $panel = new PanelStart();
    $panel->setWidth('100px');
    $panel->setFloat('right');

    $this->addElement(new ActionButtons('DeliverLine'));
  }
}