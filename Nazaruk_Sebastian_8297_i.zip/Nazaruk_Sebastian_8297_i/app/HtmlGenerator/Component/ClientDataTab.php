<?php
namespace App\HtmlGenerator\Component;

use App\HtmlGenerator\Forms\ClientForm;
use App\HtmlGenerator\PanelStart;
use App\HtmlGenerator\PanelEnd;
use App\Models\User;

class ClientDataTab extends Component {

  protected function init() {
    $this->addElement(new ClientForm());
    $panel = new PanelStart();
    $panel->setWidth('500px');
    $this->addElement($panel);
    $this->addElement(new PanelEnd());
    $user = User::getLoggedUser();

    $actionPanel = new ActionButtons();
    if (! $user->isSystemAdmin()) {
      $actionPanel->setIncludeDelete(false);
      $actionPanel->setIncludeNew(false);
    }

    $this->addElement($actionPanel);
  }
}