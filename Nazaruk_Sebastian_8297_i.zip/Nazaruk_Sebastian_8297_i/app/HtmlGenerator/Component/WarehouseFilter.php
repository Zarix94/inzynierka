<?php
namespace App\HtmlGenerator\Component;

use App\HtmlGenerator\Inputs\FilterInput;
use App\Adapter\SAdapter\CountrySAdapter;
use App\HtmlGenerator\Inputs\FilterSelect;

class WarehouseFilter extends Component {

  protected function init() {
    $this->addElement(new FilterInput('itCodeSearch', 'Kod', 'code'));
    $this->addElement(new FilterInput('itNameSearch', 'Nazwa', 'name'));
  }
}