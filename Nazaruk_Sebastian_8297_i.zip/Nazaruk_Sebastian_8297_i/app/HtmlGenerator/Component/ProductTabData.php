<?php
namespace App\HtmlGenerator\Component;

use App\HtmlGenerator\PanelStart;
use App\HtmlGenerator\PanelEnd;
use App\HtmlGenerator\Forms\ProductForm;
use App\Models\User;

class ProductTabData extends Component {

  protected function init() {
    $this->addElement(new ProductForm());
    $panel = new PanelStart();
    $panel->setWidth('1000px');
    $this->addElement($panel);
    $this->addElement(new PanelEnd());
    $user = User::getLoggedUser();
    if (! $user->isClientUser())
      $this->addElement(new ActionButtons());
  }
}