<?php
namespace App\HtmlGenerator\Component;

use App\HtmlGenerator\Inputs\FilterInput;
use App\Adapter\SAdapter\CountrySAdapter;
use App\HtmlGenerator\Inputs\FilterSelect;
use App\Adapter\SAdapter\SkuUnitSAdapter;
use App\Models\User;
use App\Adapter\SAdapter\ClientSAdapter;

class ProductFilter extends Component {

  protected function init() {
    $this->addElement(new FilterInput('itProductCodeSearch', 'Kod', 'code'));
    $this->addElement(new FilterInput('itProductNameSearch', 'Nazwa', 'name'));

    $selectUnit = new FilterSelect('itUnitSearch', 'Jednostka składowania', 'unit_id');
    $selectUnit->setAdapter(new SkuUnitSAdapter());
    $this->addElement($selectUnit);

    $user = User::getLoggedUser();
    if ($user->isSystemAdmin()) {
      $selectClient = new FilterSelect('itClientSearch', 'Klient', 'client_id');
      $selectClient->setAdapter(new ClientSAdapter());
      $this->addElement($selectClient);
    }
  }
}