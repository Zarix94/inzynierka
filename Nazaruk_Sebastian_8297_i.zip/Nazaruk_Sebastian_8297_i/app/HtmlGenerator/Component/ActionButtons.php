<?php
namespace App\HtmlGenerator\Component;

use App\HtmlGenerator\PanelStart;
use App\HtmlGenerator\PanelEnd;
use App\HtmlGenerator\Inputs\Button;

class ActionButtons extends Component {

  private $modelSuffix = '';

  private $panel = true;

  private $includeSave = true;

  private $includeNew = true;

  private $includeDelete = true;

  public function setIncludeSave(bool $include): void {
    $this->includeSave = $include;
  }

  public function setIncludeNew(bool $include): void {
    $this->includeNew = $include;
  }

  public function setIncludeDelete(bool $include): void {
    $this->includeDelete = $include;
  }

  public function __construct(string $modelSuffix = '', bool $panel = true) {
    $this->modelSuffix = $modelSuffix;
    $this->panel = $panel;
  }

  protected function init() {
    if ($this->panel) {
      $panel = new PanelStart();
      $panel->setWidth('100px');
      $panel->setFloat('right');
      $this->addElement($panel);
    }

    if ($this->includeSave)
      $this->addElement(new Button('btSave' . $this->modelSuffix, 'Zapisz', Button::BT_GREEN));
    if ($this->includeNew)
      $this->addElement(new Button('btNew' . $this->modelSuffix, 'Nowy'));
    if ($this->includeDelete)
      $this->addElement(new Button('btDelete' . $this->modelSuffix, 'Usuń', Button::BT_RED));

    if ($this->panel)
      $this->addElement(new PanelEnd());
  }
}