<?php
namespace App\HtmlGenerator\Component;

use App\HtmlGenerator\PanelStart;
use App\HtmlGenerator\PanelEnd;
use App\HtmlGenerator\Forms\CountryForm;
use App\HtmlGenerator\Forms\DictionaryForm;

class SkuConditionData extends Component {

  protected function init() {
    $this->addElement(new DictionaryForm('SkuCondition', 'sku-condition-form'));
    $panel = new PanelStart();
    $panel->setWidth('1000px');
    $this->addElement($panel);
    $this->addElement(new PanelEnd());
    $this->addElement(new ActionButtons('SkuCondition'));
  }
}