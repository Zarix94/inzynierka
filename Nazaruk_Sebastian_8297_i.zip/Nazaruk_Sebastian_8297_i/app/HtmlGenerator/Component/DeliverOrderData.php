<?php
namespace App\HtmlGenerator\Component;

use App\HtmlGenerator\PanelStart;
use App\HtmlGenerator\PanelEnd;
use App\HtmlGenerator\Forms\WarehouseForm;
use App\HtmlGenerator\Forms\DeliverOrderForm;
use App\HtmlGenerator\Inputs\Button;
use App\Models\User;

class DeliverOrderData extends Component {

  protected function init() {
    $this->addElement(new DeliverOrderForm());
    $panel = new PanelStart();
    $panel->setWidth('1000px');
    $this->addElement($panel);
    $this->addElement(new PanelEnd());
    $panel = new PanelStart();
    $panel->setWidth('100px');
    $panel->setFloat('right');

    $user = User::getLoggedUser();

    $this->addElement($panel);
    if ($user->isSystemAdmin())
      $this->addElement(new Button('btChangeOrderStatus', 'Zmień status'));

    if (! $user->isSystemAdmin())
      $this->addElement(new Button('btRealizeOrder', 'Przekaż do realizacji'));

    $actionButtons = new ActionButtons('Deliver', false);
    if ($user->isSystemAdmin()) {
      $actionButtons->setIncludeNew(false);
      $actionButtons->setIncludeDelete(false);
    }

    $this->addElement($actionButtons);

    $this->addElement(new PanelEnd());
  }
}