<?php
namespace App\HtmlGenerator;

class DataTable extends Generator {

  private $columns = [];

  public function setColumns(array $columns) {
    $this->columns = $columns;
  }

  public function generateHtml(): string {
    $html = '';

    $html .= '<table id="' . $this->getElementId() . '" class="display">';
    $html .= '  <thead>';
    $html .= '    <tr>';

    foreach ($this->columns as $dataKey => $columnName) {

      $html .= '      <th data-id="' . $dataKey . '">' . $columnName . '</th>';
    }
    $html .= '    </tr>';
    $html .= '  </thead>';
    $html .= '  <tbody>';
    $html .= '  </tbody>';
    $html .= '</table>';

    return $html;
  }
}