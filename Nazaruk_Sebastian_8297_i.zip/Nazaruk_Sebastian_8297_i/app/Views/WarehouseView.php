<?php
namespace App\Views;

class WarehouseView extends View {

  private function generateDatatable(): void {
    $tableGenerator = new \App\HtmlGenerator\DataTable();
    $tableGenerator->setElementId('tblWarehouse');
    $tableGenerator->setColumns([
      'id' => 'id',
      'code' => 'Kod',
      'name' => 'Nazwa'
    ]);

    $this->dataTables['tblWarehouse'] = $tableGenerator->generateHtml();
  }

  private function generateInventoryDatatable(): void {
    $tableGenerator = new \App\HtmlGenerator\DataTable();
    $tableGenerator->setElementId('tblWarehouseInventory');
    $tableGenerator->setColumns([
      'id' => 'id',
      'client' => 'Klient',
      'code' => 'Kod',
      'name' => 'Nazwa',
      'unit' => 'Jednostka składowania',
      'condition' => 'Kondycja towaru',
      'quantity' => 'Ilość'
    ]);

    $this->dataTables['tblWarehouseInventory'] = $tableGenerator->generateHtml();
  }

  protected function generate(): void {
    $this->generateDatatable();
    $this->generateInventoryDatatable();
    $this->components['filters'] = \App\HtmlGenerator\Component\WarehouseFilter::getComponent();
    $this->components['warehouse-data'] = \App\HtmlGenerator\Component\WarehouseData::getComponent();
  }
}