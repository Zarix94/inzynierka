<?php
namespace App\Views;

class CarrierView extends View {

  private function generateDatatable(): void {
    $tableGenerator = new \App\HtmlGenerator\DataTable();
    $tableGenerator->setElementId('tblCarrier');
    $tableGenerator->setColumns([
      'id' => 'id',
      'code' => 'Kod',
      'name' => 'Nazwa'
    ]);

    $this->dataTables['tblCarrier'] = $tableGenerator->generateHtml();
  }

  protected function generate(): void {
    $this->generateDatatable();
    $this->components['carrier-data'] = \App\HtmlGenerator\Component\CarrierData::getComponent();
  }
}