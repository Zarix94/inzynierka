<?php
namespace App\Views;

use App\Models\User;

class AddressView extends View {

  private function generateDatatable(): void {
    $tableGenerator = new \App\HtmlGenerator\DataTable();
    $tableGenerator->setElementId('tblAddress');
    $columns = [];
    $columns['id'] = 'id';

    $user = User::getLoggedUser();
    if ($user->isSystemAdmin())
      $columns['client'] = 'Klient';

    $columns['code'] = 'Kod';
    $columns['name'] = 'Nazwa';
    $columns['contact_email'] = 'E-mail';
    $columns['contact_number'] = 'Numer kontaktowy';
    $columns['country'] = 'Kraj';
    $columns['city'] = 'Miasto';
    $columns['address'] = 'Adres';
    $columns['postcode'] = 'Kod pocztowy';
    $columns['description'] = 'Opis';

    $tableGenerator->setColumns($columns);

    $this->dataTables['tblAddress'] = $tableGenerator->generateHtml();
  }

  protected function generate(): void {
    $this->generateDatatable();
    $this->components['address-data'] = \App\HtmlGenerator\Component\AddressData::getComponent();
  }
}