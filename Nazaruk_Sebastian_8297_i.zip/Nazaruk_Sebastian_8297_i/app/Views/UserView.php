<?php
namespace App\Views;

use App\HtmlGenerator\Forms\ChangePasswordForm;

class UserView extends View {

  private function generateUserDatatable(): void {
    $tableGenerator = new \App\HtmlGenerator\DataTable();
    $tableGenerator->setElementId('tblUser');
    $tableGenerator->setColumns([
      'id' => 'id',
      'role' => 'Rola',
      'client' => 'Klient',
      'login' => 'Login',
      'email' => 'Nazwa',
      'first_name' => 'Imię',
      'last_name' => 'Nazwisko',
      'last_login' => 'Ostatnie logowanie',
      'last_bad_login' => 'Ostatnie nieudane logowanie'
    ]);

    $this->dataTables['tblUser'] = $tableGenerator->generateHtml();
  }

  protected function generate(): void {
    $this->generateUserDatatable();
    $this->components['user-data'] = \App\HtmlGenerator\Component\UserData::getComponent();
    $setPasswordForm = new ChangePasswordForm();
    $this->components['set-password'] = $setPasswordForm->generateHtml();
  }
}