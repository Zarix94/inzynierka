<?php
namespace App\Views;

abstract class View {

  public $dataTables = [];

  public $components = [];

  abstract protected function generate(): void;

  public static function generateView(string $view): array {
    $className = get_called_class();
    $class = new $className();
    $class->generate();

    return [
      'components' => $class->components,
      'dataTables' => $class->dataTables,
      'view' => $view
    ];
  }
}