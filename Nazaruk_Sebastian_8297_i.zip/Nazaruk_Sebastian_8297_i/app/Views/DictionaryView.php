<?php
namespace App\Views;

class DictionaryView extends View {

  private function generateCountryDatatable(): void {
    $tableGenerator = new \App\HtmlGenerator\DataTable();
    $tableGenerator->setElementId('tblCountry');
    $tableGenerator->setColumns([
      'id' => 'id',
      'code' => 'Kod',
      'name' => 'Nazwa'
    ]);

    $this->dataTables['tblCountry'] = $tableGenerator->generateHtml();
  }

  private function generateSkuConditionDatatable(): void {
    $tableGenerator = new \App\HtmlGenerator\DataTable();
    $tableGenerator->setElementId('tblSkuCondition');
    $tableGenerator->setColumns([
      'id' => 'id',
      'code' => 'Kod',
      'name' => 'Nazwa'
    ]);

    $this->dataTables['tblSkuCondition'] = $tableGenerator->generateHtml();
  }

  private function generateCarrierDatatable(): void {
    $tableGenerator = new \App\HtmlGenerator\DataTable();
    $tableGenerator->setElementId('tblCarrier');
    $tableGenerator->setColumns([
      'id' => 'id',
      'code' => 'Kod',
      'name' => 'Nazwa'
    ]);

    $this->dataTables['tblCarrier'] = $tableGenerator->generateHtml();
  }

  private function generateSkuUnitDatatable(): void {
    $tableGenerator = new \App\HtmlGenerator\DataTable();
    $tableGenerator->setElementId('tblSkuUnit');
    $tableGenerator->setColumns([
      'id' => 'id',
      'code' => 'Kod',
      'name' => 'Nazwa'
    ]);

    $this->dataTables['tblSkuUnit'] = $tableGenerator->generateHtml();
  }

  private function generateStatusDatatable(): void {
    $tableGenerator = new \App\HtmlGenerator\DataTable();
    $tableGenerator->setElementId('tblStatus');
    $tableGenerator->setColumns([
      'id' => 'id',
      'code' => 'Kod',
      'name' => 'Nazwa',
      'type' => 'Typ',
      'next_status' => 'Następny status'
    ]);

    $this->dataTables['tblStatus'] = $tableGenerator->generateHtml();
  }

  protected function generate(): void {
    $this->generateCountryDatatable();
    $this->generateSkuConditionDatatable();
    $this->generateCarrierDatatable();
    $this->generateSkuUnitDatatable();
    $this->generateStatusDatatable();
    $this->components['country-data'] = \App\HtmlGenerator\Component\CountryData::getComponent();
    $this->components['sku-condition-data'] = \App\HtmlGenerator\Component\SkuConditionData::getComponent();
    $this->components['carrier-data'] = \App\HtmlGenerator\Component\CarrierData::getComponent();
    $this->components['sku-unit-data'] = \App\HtmlGenerator\Component\SkuUnitData::getComponent();
    $this->components['status-data'] = \App\HtmlGenerator\Component\StatusData::getComponent();
  }
}