<?php
namespace App\Views;

use App\Models\User;

class ProductView extends View {

  private function generateProductDatatable(): void {
    $tableGenerator = new \App\HtmlGenerator\DataTable();
    $tableGenerator->setElementId('tblProduct');
    $columns = [
      'id' => 'id'
    ];

    $user = User::getLoggedUser();
    if ($user->isSystemAdmin())
      $columns['client'] = 'Klient';

    $columns['code'] = 'Kod';
    $columns['name'] = 'Nazwa';
    $columns['unit'] = 'Jednostka składowania';
    $columns['quantity'] = 'Ilość';

    $tableGenerator->setColumns($columns);

    $this->dataTables['tblProduct'] = $tableGenerator->generateHtml();
  }

  private function generateProductInventoryDatatable(): void {
    $tableGenerator = new \App\HtmlGenerator\DataTable();
    $tableGenerator->setElementId('tblProductInventory');
    $tableGenerator->setColumns([
      'id' => 'id',
      'warehouse' => 'Magazyn',
      'condition' => 'Kondycja towaru',
      'quantity' => 'Ilość'
    ]);

    $this->dataTables['tblProductInventory'] = $tableGenerator->generateHtml();
  }

  protected function generate(): void {
    $this->generateProductDatatable();
    $this->generateProductInventoryDatatable();
    $this->components['tab-data'] = \App\HtmlGenerator\Component\ProductTabData::getComponent();
    $this->components['filters'] = \App\HtmlGenerator\Component\ProductFilter::getComponent();
  }
}