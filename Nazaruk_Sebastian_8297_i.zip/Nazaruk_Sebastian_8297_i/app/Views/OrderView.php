<?php
namespace App\Views;

use App\Models\User;

class OrderView extends View {

  private function generateHeaderDatatable(): void {
    $tableGenerator = new \App\HtmlGenerator\DataTable();
    $tableGenerator->setElementId('tblDeliverOrder');

    $columns = [];
    $columns['id'] = 'id';
    $columns['order_date'] = 'Data dostawy';
    $user = User::getLoggedUser();

    if ($user->isSystemAdmin())
      $columns['client'] = 'Klient';

    $columns['warehouse'] = 'Magazyn';
    $columns['carrier'] = 'Przewoźnik';
    $columns['contractor_name'] = 'Kontrahent';
    $columns['country'] = 'Kraj';
    $columns['city'] = 'Miasto';
    $columns['address'] = 'Adres';
    $columns['postcode'] = 'Kod pocztowy';
    $columns['status'] = 'Status';

    $tableGenerator->setColumns($columns);

    $this->dataTables['tblDeliverOrder'] = $tableGenerator->generateHtml();
  }

  private function generateLineDatatable(): void {
    $tableGenerator = new \App\HtmlGenerator\DataTable();
    $tableGenerator->setElementId('tblDeliverLine');
    $tableGenerator->setColumns([
      'id' => 'id',
      'code' => 'Kod',
      'name' => 'Nazwa',
      'unit' => 'Jednostka składowania',
      'condition' => 'Kondycja towaru',
      'quantity' => 'Ilość'
    ]);

    $this->dataTables['tblDeliverLine'] = $tableGenerator->generateHtml();
  }

  protected function generate(): void {
    $this->generateHeaderDatatable();
    $this->generateLineDatatable();
    $this->components['order-data'] = \App\HtmlGenerator\Component\DeliverOrderData::getComponent();
    $this->components['order-line-data'] = \App\HtmlGenerator\Component\DeliverLineData::getComponent();
  }
}