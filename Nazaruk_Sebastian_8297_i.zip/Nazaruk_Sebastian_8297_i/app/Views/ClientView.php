<?php
namespace App\Views;

use App\HtmlGenerator\Inputs\Button;
use App\Models\User;

class ClientView extends View {

  private function generateClientDatatable(): void {
    $tableGenerator = new \App\HtmlGenerator\DataTable();
    $tableGenerator->setElementId('tblClient');
    $tableGenerator->setColumns([
      'id' => 'id',
      'code' => 'Kod',
      'name' => 'Nazwa',
      'nip' => 'NIP',
      'contact_email' => 'E-mail',
      'contact_number' => 'Numer kontaktowy',
      'country' => 'Kraj',
      'city' => 'Miasto',
      'address' => 'Adres',
      'postcode' => 'Kod pocztowy',
      'description' => 'Opis'
    ]);

    $this->dataTables['tblClient'] = $tableGenerator->generateHtml();
  }

  private function generateAssignTable(string $tableId) {
    $tableGenerator = new \App\HtmlGenerator\DataTable();
    $tableGenerator->setElementId($tableId);
    $columns = [
      'id' => 'id',
      'code' => 'Kod',
      'name' => 'Nazwa'
    ];

    $user = User::getLoggedUser();
    if ($user->isSystemAdmin())
      $columns['assign'] = 'Przypisz';

    $tableGenerator->setColumns($columns);
    $this->dataTables[$tableId] = $tableGenerator->generateHtml();
  }

  private function generateButton(string $id) {
    $button = new Button($id, 'Przypisz');
    return $button->generateHtml();
  }

  protected function generate(): void {
    $this->generateClientDatatable();
    $this->generateAssignTable('tblClientWarehouse');
    $this->generateAssignTable('tblClientSkuCondition');
    $this->generateAssignTable('tblClientCarrier');

    $this->components['filters'] = \App\HtmlGenerator\Component\ClientFilter::getComponent();
    $this->components['tab-data'] = \App\HtmlGenerator\Component\ClientDataTab::getComponent();

    $user = User::getLoggedUser();
    $this->components['assign-warehouse-button'] = $user->isSystemAdmin() ? $this->generateButton('btAssignWarehouseToClient') : '';
    $this->components['assign-condition-button'] = $user->isSystemAdmin() ? $this->generateButton('btAssignConditionToClient') : '';
    $this->components['assign-carrier-button'] = $user->isSystemAdmin() ? $this->generateButton('btAssignCarrierToClient') : '';
  }
}