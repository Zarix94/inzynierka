<?php
namespace App\Http\Controllers;

use App\Utils\Result;
use App\Models\DeliverOrder;
use App\Models\Address;

class OrderController extends Controller {

  public function realizeDeliver() {
    $deliverId = isset($_POST['document_id']) ? intval($_POST['document_id']) : null;
    $obj = DeliverOrder::where('id', intval($deliverId))->take(1)
      ->get()
      ->first();

    $result = new Result();
    if ($obj)
      $obj->sendToRealization($result);
    else
      $result->setError('message', 'Nie znaleziono awizacji');

    return response()->json($result);
  }

  public function getAddress() {
    $addresId = isset($_POST['address_id']) ? intval($_POST['address_id']) : null;
    $obj = Address::find($addresId);
    $result = new Result();
    if ($obj)
      $result->data = $obj;
    else
      $result->setError('message', 'Nie znaleziono adresu');

    return response()->json($result);
  }
}
