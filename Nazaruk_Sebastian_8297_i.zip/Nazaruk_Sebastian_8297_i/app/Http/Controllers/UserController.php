<?php
namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Support\Facades\Auth;
use App\Utils\Result;

class UserController extends Controller {

  public function login() {
    $result = new Result();
    if (! Auth::check()) {

      $login = isset($_POST['login']) ? $_POST['login'] : '';
      $password = isset($_POST['password']) ? $_POST['password'] : '';
      $result = User::login($login, $password);
    }

    return response()->json($result);
  }

  public function setPassword() {
    $result = new Result(false);
    $user = User::getLoggedUser();
    if (! $user->isClientUser()) {
      $userId = isset($_POST['user-id']) ? $_POST['user-id'] : '0';
      $password = isset($_POST['password']) ? $_POST['password'] : '';
      $result = User::setPassword($userId, $password);
    }

    return response()->json($result);
  }
}
