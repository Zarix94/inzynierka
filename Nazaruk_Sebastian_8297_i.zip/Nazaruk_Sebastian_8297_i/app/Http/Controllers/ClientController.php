<?php
namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth;
use App\Utils\Result;
use App\Models\Client;
use App\Models\User;
use App\Models\UserRole;

class ClientController extends Controller {

  public function assignWarehouses() {
    $clientId = isset($_POST['client_id']) ? intval($_POST['client_id']) : null;
    $warehouses = isset($_POST['warehouses']) ? $_POST['warehouses'] : [];
    $user = User::getLoggedUser();

    $result = new Result(false);
    if (Auth::check() && $clientId !== null && $user->isSystemAdmin()) {
      $client = Client::where('id', intval($clientId))->first();
      if ($client)
        $result = $client->assignWarehouse($warehouses);
    } else {
      sleep(5);
      exit();
    }

    return response()->json($result);
  }

  public function assignConditions() {
    $clientId = isset($_POST['client_id']) ? intval($_POST['client_id']) : null;
    $conditions = isset($_POST['conditions']) ? $_POST['conditions'] : [];
    $user = User::getLoggedUser();

    $result = new Result(false);
    if (Auth::check() && $clientId !== null && $user->isSystemAdmin()) {
      $client = Client::where('id', intval($clientId))->first();
      if ($client)
        $result = $client->assignCondition($conditions);
    } else {
      sleep(5);
      exit();
    }

    return response()->json($result);
  }

  public function assignCarriers() {
    $clientId = isset($_POST['client_id']) ? intval($_POST['client_id']) : null;
    $carriers = isset($_POST['carriers']) ? $_POST['carriers'] : [];
    $user = User::getLoggedUser();

    $result = new Result(false);
    if (Auth::check() && $clientId !== null && $user->isSystemAdmin()) {
      $client = Client::where('id', intval($clientId))->first();
      if ($client)
        $result = $client->assignCarriers($carriers);
    } else {
      sleep(5);
      exit();
    }

    return response()->json($result);
  }
}
