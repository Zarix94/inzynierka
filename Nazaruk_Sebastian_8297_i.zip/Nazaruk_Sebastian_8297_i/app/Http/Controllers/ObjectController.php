<?php
namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth;
use App\Utils\Result;
use App\Models\ActionLog;
use App\Models\User;

class ObjectController extends Controller {

  private function checkAuth() {
    $result = true;
    if (! Auth::check()) {
      $result = false;
      sleep(5);
    }

    return $result;
  }

  private function create(string $className, array $properties): Result {
    $result = $className::onCreateValidate($properties);
    if ($result->getResult()) {

      if (method_exists($className, 'onPreCreate'))
        $className::onPreCreate($properties);

      foreach ($properties as &$propValue)
        if ($propValue === '')
          $propValue = null;

      $obj = $className::create($properties);
      $user = User::getLoggedUser();
      ActionLog::insertCreateLog($user->id, $obj);
    }

    return $result;
  }

  private function update(string $className, int $id, array $properties): Result {
    $result = new Result();
    $obj = $className::find($id);
    if ($obj !== null)
      $result = $obj->saveObject();
    else
      $result->setError('message', 'Nie znaleziono obiektu');

    return $result;
  }

  public function save() {
    if ($this->checkAuth()) {
      $className = 'App\\Models\\' . $_POST['object']['type'];
      $id = $_POST['object']['id'];
      $properties = $_POST['object']['properties'];

      $result = new Result();
      if (method_exists($className, 'validate'))
        $result = $className::validate($properties);

      if (method_exists($className, 'onPreSave'))
        $className::onPreSave($properties);

      if ($result->getResult())
        if (intval($id) > 0)
          $result = $this->update($className, $id, $properties);
        else
          $result = $this->create($className, $properties);

      return response()->json($result);
    } else
      return view('login');
  }

  public function reset() {
    if ($this->checkAuth()) {
      $className = 'App\\Models\\' . $_POST['type'];
      $obj = new $className();

      $result = new Result();
      $result->data['fields'] = $obj->getFillable();
      return response()->json($result);
    } else
      return view('login');
  }

  public function get() {
    if ($this->checkAuth()) {
      $className = 'App\\Models\\' . $_POST['type'];
      $id = $_POST['id'];

      $obj = $className::where('id', $id)->take(1)->get();
      if (method_exists($obj[0], 'onGet'))
        $obj[0]->onGet();

      $result = new Result();
      $result->data['obj'] = $obj;
      return response()->json($result);
    } else {
      sleep(5);
      exit();
    }
  }

  public function remove() {
    if ($this->checkAuth()) {
      $className = 'App\\Models\\' . $_POST['type'];
      $id = $_POST['id'];

      $obj = $className::find($id);
      $res = $obj->delete();

      $user = User::getLoggedUser();
      ActionLog::insertCreateLog($user->id, $obj);
      $result = new Result($res);
      return response()->json($result);
    } else
      return view('login');
  }
}
