<?php
namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth;
use App\Adapter\DTAdapter\ClientDTAdapter;

class AdapterController extends Controller {

  public function getTable() {
    if (Auth::check()) {
      $adapter = isset($_POST['adapter']) ? $_POST['adapter'] : '';
      $data = isset($_POST['data']) ? $_POST['data'] : [];
      $adapter = 'App\Adapter\DTAdapter\\' . $adapter;
      $adapterObj = new $adapter($data);

      return response()->json($adapterObj->get());
    } else {
      sleep(5);
      return view('login');
    }
  }
}
