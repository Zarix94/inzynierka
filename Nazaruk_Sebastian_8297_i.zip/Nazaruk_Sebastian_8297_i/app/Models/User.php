<?php
namespace App\Models;

use Illuminate\Support\Facades\Auth;
use App\Utils\Result;
use App\Utils\Validator;
use App\Utils\Error;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;

class User extends UserModel {

  /**
   * The attributes that are mass assignable.
   *
   * @var array
   */
  protected $table = 'users';

  protected $fillable = [
    'login',
    'email',
    'password',
    'first_name',
    'last_name',
    'client_id',
    'role_id',
    'last_login',
    'last_bad_login'
  ];

  /**
   * The attributes that should be hidden for arrays.
   *
   * @var array
   */
  protected $hidden = [
    'password',
    'remember_token'
  ];

  /**
   * The attributes that should be cast to native types.
   *
   * @var array
   */
  protected $casts = [
    'email_verified_at' => 'datetime'
  ];

  /**
   * The attributes that should be mutated to dates.
   *
   * @var array
   */
  protected $dates = [
    'deleted_at'
  ];

  public function role() {
    return $this->belongsTo(UserRole::class);
  }

  public function client() {
    return $this->belongsTo(Client::class);
  }

  private static function badLogin(string $login, Result &$result): void {
    $user = User::where('login', $login)->take(1)
      ->get()
      ->first();

    if ($user) {
      $user->last_bad_login = date('Y-m-d H:i:s');
      $user->push();
      AuthLog::insertBadLoginLog($user->id);
    }

    $result->setError('login', 'Niepoprawny login lub hasło');
    $result->setError('password', 'Niepoprawny login lub hasło');
  }

  public static function login(String $login, String $password): Result {
    $result = new Result();

    $credentials = [
      'login' => $login,
      'password' => $password
    ];

    $result->setResult(Auth::attempt($credentials, true));
    if (! $result->getResult())
      self::badLogin($login, $result);
    else {
      $user = self::getLoggedUser();
      $user->last_login = date('Y-m-d H:i:s');
      $user->push();
      AuthLog::insertLoginLog($user->id);
    }

    return $result;
  }

  private static function validateRoleFields(Result &$result, array &$properties): void {
    $role = UserRole::find($properties['role_id']);
    if ($role->const_name !== UserRole::SYSTEM_ADMIN)
      if (! isset($properties['client_id']) || Validator::isEmptyOrZero($properties['client_id']))
        $result->setError('client_id', Error::REQUIRED_CHOOSE_VALUE);
  }

  public static function validate(array $properties): Result {
    $result = new Result();

    $user = self::getLoggedUser();
    if ($user->isClientUser())
      $result->setError('message', Error::LACK_OF_ACCESS);

    if (! isset($properties['login']) || Validator::isEmpty($properties['login']))
      $result->setError('login', Error::FIELD_REQUIRED);

    if (! isset($properties['email']) || Validator::isEmpty($properties['email']))
      $result->setError('email', Error::FIELD_REQUIRED);

    if (! isset($properties['role_id']) || Validator::isEmptyOrZero($properties['role_id']))
      $result->setError('role_id', Error::REQUIRED_CHOOSE_VALUE);
    else
      self::validateRoleFields($result, $properties);

    return $result;
  }

  public static function onCreateValidate(array $properties): Result {
    $result = new Result();

    if (! Validator::isUnique('User', 'login', $properties['login']))
      $result->setError('login', Error::FIELD_NOT_UNIQUE);

    if (! Validator::isUnique('User', 'email', $properties['email']))
      $result->setError('email', Error::FIELD_NOT_UNIQUE);

    return $result;
  }

  public function onUpdateValidate(array $properties): Result {
    $result = new Result();

    if (! Validator::isUnique('User', 'login', $properties['login'], $this->id))
      $result->setError('login', Error::FIELD_NOT_UNIQUE);

    if (! Validator::isUnique('User', 'email', $properties['email'], $this->id))
      $result->setError('email', Error::FIELD_NOT_UNIQUE);

    return $result;
  }

  public static function onPreCreate(array &$properties): void {
    $user = self::getLoggedUser();
    if ($user->isSystemAdmin())
      $properties['client_id'] = $properties['client_id'] == 0 ? null : $properties['client_id'];
    else
      $properties['client_id'] = $user->client->id;

    $properties['password'] = Hash::make(Str::uuid());
  }

  public static function getLoggedUser(): User {
    return Auth::user();
  }

  public function isSystemAdmin(): bool {
    return $this->role->const_name == UserRole::SYSTEM_ADMIN;
  }

  public function isClientAdmin(): bool {
    return $this->role->const_name == UserRole::CLIENT_ADMIN;
  }

  public function isClientUser(): bool {
    return $this->role->const_name == UserRole::CLIENT_USER;
  }

  public static function logout(Request $request): void {
    Auth::logout();
    $request->session()->invalidate();
    $request->session()->regenerateToken();
  }

  private static function validPassword($password): bool {
    $result = true;
    if (mb_strlen($password) < 6)
      $result = false;
    return $result;
  }

  public static function setPassword(int $userId, string $password): Result {
    $result = new Result();
    if (! self::validPassword($password))
      $result->setError('message', 'Hasło musi składać się z co najmniej 6 znaków');
    else {
      $user = self::getLoggedUser();
      $conditions = [];
      $conditions[] = [
        'id',
        '=',
        intvaL($userId)
      ];

      if (! $user->isSystemAdmin())
        $conditions[] = [
          'user_id',
          '=',
          $user->client->id
        ];

      $obj = User::where($conditions)->get()->first();

      if ($obj) {
        $obj->password = Hash::make($password);
        $obj->save();
      } else
        $result->setError('message', 'Nie znaleziono użytkownika');
    }
    return $result;
  }
}
