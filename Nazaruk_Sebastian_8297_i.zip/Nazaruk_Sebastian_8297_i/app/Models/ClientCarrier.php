<?php
namespace App\Models;

class ClientCarrier extends BaseModel {

  protected $table = 'client_sku_condition';

  /**
   * The attributes that are mass assignable.
   *
   * @var array
   */
  protected $fillable = [
    'client_id',
    'carrier_id'
  ];
}
