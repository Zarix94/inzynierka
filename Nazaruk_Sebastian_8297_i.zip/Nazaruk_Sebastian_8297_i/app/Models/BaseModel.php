<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Utils\Result;
use App\Utils\Validator;
use App\Utils\Error;

abstract class BaseModel extends Model {
  use HasFactory, SoftDeletes;

  public static function validate(array $properties): Result {
    return new Result();
  }

  public function onUpdateValidate(array $properties): Result {
    return new Result();
  }

  public static function onCreateValidate(array $properties): Result {
    return new Result();
  }

  public static function onDeleteValidate(array $properties): Result {
    return new Result();
  }

  public static function onPreCreate(array &$properties): void {}

  public static function onPreSave(array &$properties): void {}

  public function onGet(): void {}

  public function fillableExist(string $propName): bool {
    $filableArray = $this->getFillable();
    $result = false;
    foreach ($filableArray as $fillable)
      if ($propName === $fillable) {
        $result = true;
        break;
      }
    return $result;
  }

  public function saveObject(array $properties): Result {
    $result = $this->onUpdateValidate($properties);
    foreach ($properties as $propName => $propValue) {
      if ($this->fillableExist($propName)) {
        if ($propValue === '')
          $propValue = null;
        $this->$propName = $propValue;
      }
    }

    $this->save();
    $user = User::getLoggedUser();
    ActionLog::insertSaveLog($user->id, $this);
    return $result;
  }
}
