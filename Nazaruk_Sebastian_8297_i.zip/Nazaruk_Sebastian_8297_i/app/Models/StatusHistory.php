<?php
namespace App\Models;

class StatusHistory extends BaseModel {

  protected $fillable = [
    'status_id',
    'document_id',
    'change_time'
  ];
}
