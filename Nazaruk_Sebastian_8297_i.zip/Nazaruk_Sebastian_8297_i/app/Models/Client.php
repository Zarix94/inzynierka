<?php
namespace App\Models;

use App\Utils\Result;
use App\Utils\Validator;
use App\Utils\Error;
use Illuminate\Support\Facades\DB;

class Client extends BaseModel {

  protected $table = 'client';

  /**
   * The attributes that are mass assignable.
   *
   * @var array
   */
  protected $fillable = [
    'code',
    'name',
    'nip',
    'contact_email',
    'contact_number',
    'country_id',
    'city',
    'address',
    'postcode',
    'description'
  ];

  /**
   * The attributes that should be mutated to dates.
   *
   * @var array
   */
  protected $dates = [
    'deleted_at'
  ];

  public function warehouses() {
    return $this->belongsToMany(Warehouse::class);
  }

  public static function onPreSave(array &$properties): void {
    $user = User::getLoggedUser();
    if (! $user->isSystemAdmin()) {
      $newProperties = [];
      foreach ($properties as $prop => $value)
        if ($prop != 'code' && $prop != 'name' && $prop != 'nip')
          $newProperties[$prop] = $value;

      $properties = $newProperties;
    }
  }

  public static function validate(array $properties): Result {
    $result = new Result();
    $user = User::getLoggedUser();
    if ($user->isClientUser())
      $result->setError('message', Error::LACK_OF_ACCESS);

    if ($user->isSystemAdmin()) {
      if (! isset($properties['code']) || Validator::isEmpty($properties['code']))
        $result->setError('code', Error::FIELD_REQUIRED);

      if (! isset($properties['name']) || Validator::isEmpty($properties['name']))
        $result->setError('name', Error::FIELD_REQUIRED);

      if (! isset($properties['nip']) || Validator::isEmpty($properties['nip']))
        $result->setError('nip', Error::FIELD_REQUIRED);
    }
    if (! isset($properties['contact_number']) || Validator::isEmpty($properties['contact_number']))
      $result->setError('contact_number', Error::FIELD_REQUIRED);

    if (! isset($properties['country_id']) || Validator::isEmptyOrZero($properties['country_id']))
      $result->setError('country_id', Error::REQUIRED_CHOOSE_VALUE);

    return $result;
  }

  public static function onCreateValidate(array $properties): Result {
    $result = new Result();

    if (! Validator::isUnique('Client', 'code', $properties['code']))
      $result->setError('code', Error::FIELD_NOT_UNIQUE);

    if (! Validator::isUnique('Client', 'nip', $properties['nip']))
      $result->setError('nip', Error::FIELD_NOT_UNIQUE);

    return $result;
  }

  public function onUpdateValidate(array $properties): Result {
    $result = new Result();

    if (! Validator::isUnique('Client', 'code', $properties['code'], $this->id))
      $result->setError('code', Error::FIELD_NOT_UNIQUE);

    if (! Validator::isUnique('Client', 'nip', $properties['nip'], $this->id))
      $result->setError('nip', Error::FIELD_NOT_UNIQUE);

    return $result;
  }

  public function assignWarehouse(array $warehouses): Result {
    $result = new Result();

    DB::table('client_warehouse')->where('client_id', '=', $this->id)->delete();
    foreach ($warehouses as $warehouseId)
      DB::table('client_warehouse')->insert([
        'client_id' => $this->id,
        'warehouse_id' => intval($warehouseId)
      ]);

    return $result;
  }

  public function assignCondition(array $conditions): Result {
    $result = new Result();

    DB::table('client_sku_condition')->where('client_id', '=', $this->id)->delete();
    foreach ($conditions as $conditionId)
      DB::table('client_sku_condition')->insert([
        'client_id' => $this->id,
        'sku_condition_id' => intval($conditionId)
      ]);

    return $result;
  }

  public function assignCarriers(array $carriers): Result {
    $result = new Result();

    DB::table('client_carrier')->where('client_id', '=', $this->id)->delete();
    foreach ($carriers as $carrierId)
      DB::table('client_carrier')->insert([
        'client_id' => $this->id,
        'carrier_id' => intval($carrierId)
      ]);

    return $result;
  }
}
