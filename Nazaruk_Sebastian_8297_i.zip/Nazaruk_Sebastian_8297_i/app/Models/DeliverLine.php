<?php
namespace App\Models;

class DeliverLine extends Line {

  protected $table = 'deliver_line';
}
