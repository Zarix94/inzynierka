<?php
namespace App\Models;

class ClientWarehouse extends BaseModel {

  protected $table = 'client_warehouse';

  /**
   * The attributes that are mass assignable.
   *
   * @var array
   */
  protected $fillable = [
    'client_id',
    'warehouse_id'
  ];
}
