<?php
namespace App\Models;

use App\Utils\Result;
use App\Utils\Validator;
use App\Utils\Error;
use Illuminate\Support\Facades\DB;

class DeliverOrder extends Document {

  protected $table = 'deliver_order';

  protected $logClass = 'DeliverStatusHistory';

  public static function onPreCreate(array &$properties): void {
    $properties['country_id'] = $properties['country_id'] == 0 ? null : $properties['country_id'];

    $user = User::getLoggedUser();

    $properties['client_id'] = $user->client->id;

    $obj = Status::where('code', 'DELIVER_NEW')->take(1)
      ->get()
      ->first();

    $properties['status_id'] = $obj->id;
  }

  public static function validate(array $properties): Result {
    $result = new Result();
    if (! isset($properties['order_date']) || Validator::isEmpty($properties['order_date']))
      $result->setError('order_date', Error::FIELD_REQUIRED);

    if (! isset($properties['warehouse_id']) || Validator::isEmptyOrZero($properties['warehouse_id']))
      $result->setError('warehouse_id', Error::FIELD_REQUIRED);

    if (! isset($properties['carrier_id']) || Validator::isEmptyOrZero($properties['carrier_id']))
      $result->setError('carrier_id', Error::FIELD_REQUIRED);
    return $result;
  }

  private function validateSendToRealization(Result &$result): void {
    $status = Status::where('id', $this->status_id)->take(1)
      ->get()
      ->first();

    if ($status->code != 'DELIVER_NEW')
      $result->setError('message', 'Nieprawidłowy status awizacji');
    if (DB::table('deliver_line')->where('document_id', $this->id)->count() == 0)
      $result->setError('message', 'Nie można przekazać do realizacji awizacji bez linii');
  }

  public function sendToRealization(Result &$result): void {
    $this->validateSendToRealization($result);
    if ($result->getResult())
      $this->changeStatus('DELIVER_IN_PROGRESS');
  }

  public function onGet(): void {
    $status = Status::where('id', $this->status_id)->take(1)
      ->get()
      ->first();

    $this->status_id = $status->code;
  }
}
