<?php
namespace App\Models;

use App\Utils\Result;
use App\Utils\Validator;
use App\Utils\Error;

class Product extends BaseModel {

  protected $table = 'product';

  /**
   * The attributes that are mass assignable.
   *
   * @var array
   */
  protected $fillable = [
    'code',
    'name',
    'unit_id',
    'client_id'
  ];

  /**
   * The attributes that should be mutated to dates.
   *
   * @var array
   */
  protected $dates = [
    'deleted_at'
  ];

  public static function onPreSave(array &$properties): void {
    $user = User::getLoggedUser();
    if ($user->isClientAdmin())
      $properties['client_id'] = $user->client->id;
  }

  public static function validate(array $properties): Result {
    $result = new Result();

    $user = User::getLoggedUser();
    if ($user->isClientUser())
      $result->setError('message', Error::LACK_OF_ACCESS);

    if (! isset($properties['code']) || Validator::isEmpty($properties['code']))
      $result->setError('code', Error::FIELD_REQUIRED);

    if (! isset($properties['name']) || Validator::isEmpty($properties['name']))
      $result->setError('name', Error::FIELD_REQUIRED);

    if (! isset($properties['unit_id']) || Validator::isEmptyOrZero($properties['unit_id']))
      $result->setError('unit_id', Error::FIELD_REQUIRED);

    if ($user->isSystemAdmin())
      if (! isset($properties['client_id']) || Validator::isEmptyOrZero($properties['client_id']))
        $result->setError('client_id', Error::FIELD_REQUIRED);
    return $result;
  }

  public static function onCreateValidate(array $properties): Result {
    $result = new Result();

    if (! Validator::isUnique('Product', 'code', $properties['code']))
      $result->setError('code', Error::FIELD_NOT_UNIQUE);

    return $result;
  }

  public function onUpdateValidate(array $properties): Result {
    $result = new Result();

    if (! Validator::isUnique('Product', 'code', $properties['code'], $this->id))
      $result->setError('code', Error::FIELD_NOT_UNIQUE);

    return $result;
  }
}
