<?php
namespace App\Models;

class Inventory extends BaseModel {
}
