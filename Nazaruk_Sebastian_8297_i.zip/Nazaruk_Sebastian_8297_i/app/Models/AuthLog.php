<?php
namespace App\Models;

class AuthLog extends BaseModel {

  protected $table = 'auth_log';

  const BAD_LOGIN = 'AUTH_LOG_LOGIN_FAILED';

  const LOGIN = 'AUTH_LOG_LOGIN_SUCCESS';

  protected $fillable = [
    'log_timestamp',
    'user_id',
    'log_type_id'
  ];

  private static function getLogId(string $typeName): int {
    $type = LogType::where('const_name', $typeName)->take(1)
      ->get()
      ->first();
    return $type->id;
  }

  private static function insertLog(int $userId, string $type): void {
    AuthLog::create([
      'log_timestamp' => date('Y-m-d H:i:s'),
      'user_id' => $userId,
      'log_type_id' => self::getLogId($type)
    ]);
  }

  public static function insertBadLoginLog(int $userId): void {
    self::insertLog($userId, self::BAD_LOGIN);
  }

  public static function insertLoginLog(int $userId): void {
    self::insertLog($userId, self::LOGIN);
  }
}
