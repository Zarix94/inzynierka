<?php
namespace App\Models;

class ActionLog extends BaseModel {

  protected $table = 'action_log';

  const TYPE_OBJECT_CREATE = 'OBJECT_CREATE';

  const TYPE_OBJECT_SAVE = 'OBJECT_SAVE';

  const TYPE_OBJECT_DELETE = 'OBJECT_DELETE';

  protected $fillable = [
    'log_timestamp',
    'user_id',
    'log_type_id',
    'object_json',
    'object_id',
    'class'
  ];

  private static function getLogId(string $typeName): int {
    $type = LogType::where('const_name', $typeName)->take(1)
      ->get()
      ->first();
    return $type->id;
  }

  private static function insertLog(int $userId, $object, string $type): void {
    self::create([
      'log_timestamp' => date('Y-m-d H:i:s'),
      'user_id' => $userId,
      'log_type_id' => self::getLogId($type),
      'object_id' => $object->id,
      'object_json' => $object->toJson(),
      'class' => get_class($object)
    ]);
  }

  public static function insertCreateLog(int $userId, $object): void {
    self::insertLog($userId, $object, self::TYPE_OBJECT_CREATE);
  }

  public static function insertSaveLog(int $userId, $object): void {
    self::insertLog($userId, $object, self::TYPE_OBJECT_SAVE);
  }

  public static function insertDeleteLog(int $userId, $object): void {
    self::insertLog($userId, $object, self::TYPE_OBJECT_DELETE);
  }
}
