<?php
namespace App\Models;

use App\Utils\Result;
use App\Utils\Validator;
use App\Utils\Error;

class Status extends BaseModel {

  protected $table = 'status';

  /**
   * The attributes that are mass assignable.
   *
   * @var array
   */
  protected $fillable = [
    'type',
    'name',
    'code',
    'status_after_id'
  ];

  /**
   * The attributes that should be mutated to dates.
   *
   * @var array
   */
  protected $dates = [
    'deleted_at'
  ];

  public static function onPreCreate(array &$properties): void {
    $properties['status_after_id'] = $properties['status_after_id'] == 0 ? null : $properties['status_after_id'];
  }

  public static function validate(array $properties): Result {
    $result = new Result();

    if (! isset($properties['code']) || Validator::isEmpty($properties['code']))
      $result->setError('code', Error::FIELD_REQUIRED);
    elseif (! Validator::isUnique('Status', 'code', $properties['code']))
      $result->setError('code', Error::FIELD_NOT_UNIQUE);

    if (! isset($properties['name']) || Validator::isEmpty($properties['name']))
      $result->setError('name', Error::FIELD_REQUIRED);

    if (! isset($properties['type']) || Validator::isEmptyOrZero($properties['type']))
      $result->setError('type', Error::FIELD_REQUIRED);

    return $result;
  }

  public function getId() {
    return $this->id;
  }
}
