<?php
namespace App\Models;

abstract class Document extends BaseModel {

  protected $fillable = [
    'order_date',
    'carrier_id',
    'warehouse_id',
    'country_id',
    'client_id',
    'status_id',
    'contractor_name',
    'city',
    'address',
    'postcode'
  ];

  protected $logClass = '';

  private function insertLog(int $statusId) {
    $this->logClass::create([
      'change_time' => date('Y-m-d H:i:s'),
      'status_id' => $statusId,
      'document_id' => $this->id
    ]);
  }

  public static function onPreSave(array &$properties): void {
    if ($properties['order_date'] != '')
      $properties['order_date'] = date('Y-m-d', strtotime($properties['order_date']));

    if ($properties['status_id'] != '') {
      $status = Status::where('code', $properties['status_id'])->take(1)
        ->get()
        ->first();

      $properties['status_id'] = $status->id;
    }
  }

  public function changeStatus(string $status): void {
    $status = Status::where('code', $status)->take(1)
      ->get()
      ->first();

    $this->status_id = $status->id;
    $this->insertLog($status->id);
    $this->push();
  }
}
