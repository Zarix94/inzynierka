<?php
namespace App\Models;

class ClientSkuCondition extends BaseModel {

  protected $table = 'client_sku_condition';

  /**
   * The attributes that are mass assignable.
   *
   * @var array
   */
  protected $fillable = [
    'client_id',
    'sku_condition_id'
  ];
}
