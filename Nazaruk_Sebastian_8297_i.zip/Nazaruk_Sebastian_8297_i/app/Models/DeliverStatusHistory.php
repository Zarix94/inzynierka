<?php
namespace App\Models;

class DeliverStatusHistory extends StatusHistory {

  protected $table = 'deliver_status_history';
}
