<?php
namespace App\Models;

use App\Utils\Validator;
use App\Utils\Error;
use App\Utils\Result;

class Warehouse extends BaseModel {

  protected $table = 'warehouse';

  /**
   * The attributes that are mass assignable.
   *
   * @var array
   */
  protected $fillable = [
    'code',
    'name'
  ];

  /**
   * The attributes that should be mutated to dates.
   *
   * @var array
   */
  protected $dates = [
    'deleted_at'
  ];

  public static function validate(array $properties): Result {
    $result = new Result();
    $user = User::getLoggedUser();
    if (! $user->isSystemAdmin())
      $result->setError('message', ERROR::LACK_OF_ACCESS);

    if (! isset($properties['code']) || Validator::isEmpty($properties['code']))
      $result->setError('code', Error::FIELD_REQUIRED);

    if (! isset($properties['name']) || Validator::isEmpty($properties['name']))
      $result->setError('name', Error::FIELD_REQUIRED);

    return $result;
  }

  public static function onCreateValidate(array $properties): Result {
    $result = new Result();

    if (! Validator::isUnique('Warehouse', 'code', $properties['code']))
      $result->setError('code', Error::FIELD_NOT_UNIQUE);

    return $result;
  }

  public function onUpdateValidate(array $properties): Result {
    $result = new Result();

    if (! Validator::isUnique('Warehouse', 'code', $properties['code'], $this->id))
      $result->setError('code', Error::FIELD_NOT_UNIQUE);

    return $result;
  }
}
