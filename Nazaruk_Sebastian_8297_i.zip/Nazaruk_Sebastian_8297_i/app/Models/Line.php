<?php
namespace App\Models;

use App\Utils\Result;
use App\Utils\Validator;
use App\Utils\Error;

class Line extends BaseModel {

  protected $fillable = [
    'quantity',
    'document_id',
    'condition_id',
    'product_id'
  ];

  public static function validate(array $properties): Result {
    $result = new Result();
    if (! isset($properties['product_id']) || Validator::isEmptyOrZero($properties['product_id']))
      $result->setError('product_id', Error::FIELD_REQUIRED);

    if (! isset($properties['condition_id']) || Validator::isEmptyOrZero($properties['condition_id']))
      $result->setError('condition_id', Error::FIELD_REQUIRED);

    if (! isset($properties['quantity']) || Validator::isEmptyOrZero($properties['quantity']))
      $result->setError('quantity', Error::FIELD_REQUIRED);
    return $result;
  }
}
