<?php
namespace App\Models;

class UserRole extends BaseModel {

  const SYSTEM_ADMIN = 'SYSTEM_ADMIN';

  const CLIENT_ADMIN = 'CLIENT_ADMIN';

  const CLIENT_USER = 'CLIENT_USER';

  protected $table = 'user_role';
}
