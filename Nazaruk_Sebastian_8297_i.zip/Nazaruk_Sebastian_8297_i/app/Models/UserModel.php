<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Utils\Result;
use Illuminate\Notifications\Notifiable;

abstract class UserModel extends Authenticatable {
  use HasFactory, Notifiable, SoftDeletes;

  public static function validate(array $properties): Result {
    return new Result();
  }

  public function onUpdateValidate(array $properties): Result {
    return new Result();
  }

  public static function onCreateValidate(array $properties): Result {
    return new Result();
  }

  public static function onPreCreate(array &$properties): void {}

  public static function onPreSave(array &$properties): void {}

  public function onGet(): void {}

  public function fillableExist(string $propName): bool {
    $filableArray = $this->getFillable();
    $result = false;
    foreach ($filableArray as $fillable)
      if ($propName === $fillable) {
        $result = true;
        break;
      }
    return $result;
  }

  public function saveObject(array $properties): Result {
    $result = $this->onUpdateValidate($properties);
    foreach ($properties as $propName => $propValue) {
      if ($this->fillableExist($propName)) {
        if ($propValue === '')
          $propValue = null;
        $this->$propName = $propValue;
      }
    }

    $this->save();
    $user = User::getLoggedUser();
    ActionLog::insertSaveLog($user->id, $this);
    return $result;
  }
}
