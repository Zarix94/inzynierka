<?php
namespace App\Models;

use App\Utils\Result;
use App\Utils\Validator;
use App\Utils\Error;

class Address extends BaseModel {

  protected $table = 'address';

  /**
   * The attributes that are mass assignable.
   *
   * @var array
   */
  protected $fillable = [
    'code',
    'name',
    'contact_email',
    'contact_number',
    'country_id',
    'client_id',
    'city',
    'address',
    'postcode',
    'description'
  ];

  /**
   * The attributes that should be mutated to dates.
   *
   * @var array
   */
  protected $dates = [
    'deleted_at'
  ];

  public static function onPreSave(array &$properties): void {
    $user = User::getLoggedUser();
    if ($user->isClientAdmin())
      $properties['client_id'] = $user->client->id;
  }

  public static function validate(array $properties): Result {
    $result = new Result();
    if (! isset($properties['code']) || Validator::isEmpty($properties['code']))
      $result->setError('code', Error::FIELD_REQUIRED);

    if (! isset($properties['name']) || Validator::isEmpty($properties['name']))
      $result->setError('name', Error::FIELD_REQUIRED);

    if (! isset($properties['city']) || Validator::isEmpty($properties['city']))
      $result->setError('city', Error::FIELD_REQUIRED);

    if (! isset($properties['address']) || Validator::isEmpty($properties['address']))
      $result->setError('address', Error::FIELD_REQUIRED);

    if (! isset($properties['postcode']) || Validator::isEmpty($properties['postcode']))
      $result->setError('postcode', Error::FIELD_REQUIRED);

    if (! isset($properties['country_id']) || Validator::isEmptyOrZero($properties['country_id']))
      $result->setError('country_id', Error::REQUIRED_CHOOSE_VALUE);

    $user = User::getLoggedUser();
    if ($user->isSystemAdmin())
      if (! isset($properties['client_id']) || Validator::isEmptyOrZero($properties['client_id']))
        $result->setError('client_id', Error::FIELD_REQUIRED);

    return $result;
  }

  public static function onCreateValidate(array $properties): Result {
    $result = new Result();

    if (! Validator::isUnique('Address', 'code', $properties['code']))
      $result->setError('code', Error::FIELD_NOT_UNIQUE);

    return $result;
  }

  public function onUpdateValidate(array $properties): Result {
    $result = new Result();

    if (! Validator::isUnique('Address', 'code', $properties['code'], $this->id))
      $result->setError('code', Error::FIELD_NOT_UNIQUE);

    return $result;
  }
}
