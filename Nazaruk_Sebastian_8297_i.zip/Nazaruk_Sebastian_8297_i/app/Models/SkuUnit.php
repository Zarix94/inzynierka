<?php
namespace App\Models;

use App\Utils\Result;
use App\Utils\Validator;
use App\Utils\Error;

class SkuUnit extends BaseModel {

  protected $table = 'sku_unit';

  /**
   * The attributes that are mass assignable.
   *
   * @var array
   */
  protected $fillable = [
    'code',
    'name'
  ];

  /**
   * The attributes that should be mutated to dates.
   *
   * @var array
   */
  protected $dates = [
    'deleted_at'
  ];

  public static function validate(array $properties): Result {
    $result = new Result();

    if (! isset($properties['code']) || Validator::isEmpty($properties['code']))
      $result->setError('code', Error::FIELD_REQUIRED);
    elseif (! Validator::isUnique('SkuUnit', 'code', $properties['code']))
      $result->setError('code', Error::FIELD_NOT_UNIQUE);

    if (! isset($properties['name']) || Validator::isEmpty($properties['name']))
      $result->setError('name', Error::FIELD_REQUIRED);

    return $result;
  }

  public static function onCreateValidate(array $properties): Result {
    $result = new Result();

    if (! Validator::isUnique('SkuUnit', 'code', $properties['code']))
      $result->setError('code', Error::FIELD_NOT_UNIQUE);

    return $result;
  }

  public function onUpdateValidate(array $properties): Result {
    $result = new Result();

    if (! Validator::isUnique('SkuUnit', 'code', $properties['code'], $this->id))
      $result->setError('code', Error::FIELD_NOT_UNIQUE);

    return $result;
  }
}
