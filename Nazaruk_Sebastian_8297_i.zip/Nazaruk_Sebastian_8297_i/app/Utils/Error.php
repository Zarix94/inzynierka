<?php
namespace App\Utils;

class Error {

  const FIELD_REQUIRED = 'Wypełnij to pole';

  const FIELD_NOT_UNIQUE = 'Wartość musi być unikalna';

  const REQUIRED_CHOOSE_VALUE = 'Wybór wymagany';

  const LACK_OF_ACCESS = 'Brak uprawnień do zapisu obiektu';
}