<?php
namespace App\Utils;

use function PHPUnit\Framework\isEmpty;

class Validator {

  public static function isUnique(string $className, string $propName, string $value, int $objectId = 0): bool {
    $className = 'App\\Models\\' . $className;
    $conditions = [];
    $conditions[] = [
      $propName,
      '=',
      $value
    ];

    if ($objectId != 0) {
      $conditions[] = [
        'id',
        '!=',
        $objectId
      ];
    }

    $obj = $className::where($conditions)->take(1)->get();
    return count($obj->toArray()) === 0;
  }

  public static function isEmpty(string $value): bool {
    return $value === '' || $value === null;
  }

  public static function isEmptyOrZero(string $value): bool {
    $result = self::isEmpty($value);
    if ($result === false)
      $result = intval($value) === 0;

    return $result;
  }
}