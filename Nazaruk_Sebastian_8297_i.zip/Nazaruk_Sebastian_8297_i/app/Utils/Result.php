<?php
namespace App\Utils;

class Result {

  public $result = true;

  public $errors = array();

  public $data = array();

  public function __construct(bool $result = true) {
    $this->result = $result;
  }

  protected function setErrorMessage(String $target = 'message', ?string $error = null): void {
    if (! isset($this->errors[$target]))
      $this->errors[$target] = array();

    $this->errors[$target][] = $error;
  }

  public function setError(String $target = 'message', $error = null): void {
    if ($error != null)
      $this->setErrorMessage($target, $error);

    $this->result = false;
  }

  public function setResult(bool $result): void {
    $this->result = $result;
  }

  public function getResult(): bool {
    return $this->result;
  }

  public function getErrors(): array {
    return $this->errors;
  }

  public function mergeErrors(array $errors): void {
    $this->errors = array_merge($this->errors, $errors);

    if (count($this->errors) > 0)
      $this->result = false;
  }
}
?>