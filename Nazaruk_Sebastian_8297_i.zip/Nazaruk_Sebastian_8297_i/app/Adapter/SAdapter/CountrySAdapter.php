<?php
namespace App\Adapter\SAdapter;

use App\Adapter\Adapter;

class CountrySAdapter extends Adapter {

  protected $limit = - 1;

  protected $columns = [
    'country.id',
    'country.name'
  ];

  protected $table = 'country';

  protected $includeDeleted = true;
}
