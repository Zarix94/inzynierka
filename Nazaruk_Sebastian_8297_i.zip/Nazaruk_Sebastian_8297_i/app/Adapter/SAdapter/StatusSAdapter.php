<?php
namespace App\Adapter\SAdapter;

use App\Adapter\Adapter;

class StatusSAdapter extends Adapter {

  protected $limit = - 1;

  protected $columns = [
    'status.id',
    'status.name'
  ];

  protected $table = 'status';
}
