<?php
namespace App\Adapter\SAdapter;

use App\Adapter\Adapter;

class ProductSAdapter extends Adapter {

  protected $limit = - 1;

  protected $columns = [
    'product.id',
    'product.name'
  ];

  protected $table = 'product';
}
