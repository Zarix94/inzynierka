<?php
namespace App\Adapter\SAdapter;

use App\Adapter\Adapter;
use Illuminate\Support\Facades\DB;
use App\Models\User;

class AddressSAdapter extends Adapter {

  protected $limit = - 1;

  protected $columns = [
    'id',
    'name'
  ];

  protected $table = 'address';

  protected $includeDeleted = false;

  private function addCondition(int $clientId): void {
    $this->where[] = [
      'address.client_id',
      '=',
      $clientId
    ];
  }

  protected function onRequest(): void {
    $user = User::getLoggedUser();
    if (! $user->isSystemAdmin())
      $this->addCondition($user->client->id);
  }
}
