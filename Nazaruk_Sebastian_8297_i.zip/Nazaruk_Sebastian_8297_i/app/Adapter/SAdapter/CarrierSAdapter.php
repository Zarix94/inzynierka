<?php
namespace App\Adapter\SAdapter;

use App\Adapter\Adapter;
use Illuminate\Support\Facades\DB;
use App\Models\User;

class CarrierSAdapter extends Adapter {

  protected $limit = - 1;

  protected $columns = [
    'id',
    'name'
  ];

  protected $table = 'carrier';

  protected $includeDeleted = false;

  private function joinTable(int $clientId): void {
    $joinConditions = [];
    $joinConditions[] = [
      'carrier.id',
      '=',
      'client_carrier.carrier_id'
    ];

    $joinConditions[] = [
      'client_carrier.client_id',
      '=',
      DB::raw(DB::connection()->getPdo()->quote($clientId))
    ];

    $this->joinTable['client_carrier'] = $joinConditions;
  }

  private function addCondition(int $clientId): void {
    $this->where[] = [
      'client_carrier.client_id',
      '=',
      $clientId
    ];
  }

  protected function onRequest(): void {
    $user = User::getLoggedUser();
    if (! $user->isSystemAdmin()) {
      $this->joinTable($user->client->id);
      $this->addCondition($user->client->id);
    }
  }
}
