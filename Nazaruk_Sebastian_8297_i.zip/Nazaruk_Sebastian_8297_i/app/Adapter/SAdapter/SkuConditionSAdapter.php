<?php
namespace App\Adapter\SAdapter;

use App\Adapter\Adapter;

class SkuConditionSAdapter extends Adapter {

  protected $limit = - 1;

  protected $columns = [
    'id',
    'name'
  ];

  protected $table = 'sku_condition';
}
