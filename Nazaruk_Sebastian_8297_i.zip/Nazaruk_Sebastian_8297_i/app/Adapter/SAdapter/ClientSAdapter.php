<?php
namespace App\Adapter\SAdapter;

use App\Adapter\Adapter;

class ClientSAdapter extends Adapter {

  protected $limit = - 1;

  protected $columns = [
    'client.id',
    'client.name'
  ];

  protected $table = 'client';

  protected $includeDeleted = true;
}
