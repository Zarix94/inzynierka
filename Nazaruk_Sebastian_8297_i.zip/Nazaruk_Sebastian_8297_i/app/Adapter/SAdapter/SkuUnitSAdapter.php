<?php
namespace App\Adapter\SAdapter;

use App\Adapter\Adapter;

class SkuUnitSAdapter extends Adapter {

  protected $limit = - 1;

  protected $columns = [
    'id',
    'name'
  ];

  protected $table = 'sku_unit';

  protected $includeDeleted = true;
}
