<?php
namespace App\Adapter\SAdapter;

use App\Adapter\Adapter;
use App\Models\UserRole;
use App\Models\User;

class RoleSAdapter extends Adapter {

  protected $columns = [
    'user_role.id',
    'user_role.name'
  ];

  protected $table = 'user_role';

  protected $includeDeleted = true;

  protected function onWhere(): void {
    $user = User::getLoggedUser();
    if (! $user->isSystemAdmin())
      $this->where[] = [
        'user_role.const_name',
        '!=',
        UserRole::SYSTEM_ADMIN
      ];
  }
}
