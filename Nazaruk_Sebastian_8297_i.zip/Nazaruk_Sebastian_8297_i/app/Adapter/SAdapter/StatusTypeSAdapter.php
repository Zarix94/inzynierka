<?php
namespace App\Adapter\SAdapter;

use App\Adapter\Adapter;

class StatusTypeSAdapter extends Adapter {

  public function get(): array {}
}
