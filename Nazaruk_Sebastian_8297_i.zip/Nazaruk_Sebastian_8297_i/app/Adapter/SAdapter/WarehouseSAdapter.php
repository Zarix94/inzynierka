<?php
namespace App\Adapter\SAdapter;

use App\Adapter\Adapter;
use Illuminate\Support\Facades\DB;
use App\Models\User;

class WarehouseSAdapter extends Adapter {

  protected $limit = - 1;

  protected $columns = [
    'warehouse.id',
    'warehouse.name'
  ];

  protected $table = 'warehouse';

  private function joinTable(int $clientId): void {
    $joinConditions = [];
    $joinConditions[] = [
      'warehouse.id',
      '=',
      'client_warehouse.warehouse_id'
    ];

    $joinConditions[] = [
      'client_warehouse.client_id',
      '=',
      DB::raw(DB::connection()->getPdo()->quote($clientId))
    ];

    $this->joinTable['client_warehouse'] = $joinConditions;
  }

  private function addCondition(int $clientId): void {
    $this->where[] = [
      'client_warehouse.client_id',
      '=',
      $clientId
    ];
  }

  protected function onRequest(): void {
    $user = User::getLoggedUser();
    if (! $user->isSystemAdmin()) {
      $this->joinTable($user->client->id);
      $this->addCondition($user->client->id);
    }
  }
}
