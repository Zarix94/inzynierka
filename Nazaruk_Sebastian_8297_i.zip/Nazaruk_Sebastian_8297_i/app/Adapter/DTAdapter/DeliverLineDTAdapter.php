<?php
namespace App\Adapter\DTAdapter;

use App\Adapter\Adapter;

class DeliverLineDTAdapter extends Adapter {

  protected $columns = [
    'deliver_line.id',
    'product.code',
    'product.name',
    'sku_unit.name AS unit',
    'deliver_line.quantity',
    'sku_condition.name as condition'
  ];

  protected $table = 'deliver_line';

  protected $joinTable = [
    'product' => [
      [
        'deliver_line.product_id',
        '=',
        'product.id'
      ]
    ],
    'sku_unit' => [
      [
        'product.unit_id',
        '=',
        'sku_unit.id'
      ]
    ],

    'sku_condition' => [
      [
        'deliver_line.condition_id',
        '=',
        'sku_condition.id'
      ]
    ]
  ];

  protected function onWhere(): void {
    $orderId = isset($this->data['id']) ? intval($this->data['id']) : - 1;
    $this->where[] = [
      'deliver_line.document_id',
      '=',
      $orderId
    ];
  }
}
