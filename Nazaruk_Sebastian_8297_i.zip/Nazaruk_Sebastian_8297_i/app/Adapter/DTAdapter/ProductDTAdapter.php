<?php
namespace App\Adapter\DTAdapter;

use App\Adapter\Adapter;
use App\Models\User;

class ProductDTAdapter extends Adapter {

  protected $columns = [
    'product.id',
    'product.code',
    'product.name',
    'sku_unit.name AS unit',
    'client.name as client'
  ];

  protected $table = 'product';

  protected $sum = [
    'inventory.quantity' => 'quantity'
  ];

  protected $groupBy = [
    'product.id',
    'product.code',
    'product.name',
    'sku_unit.name',
    'client.name'
  ];

  protected $joinTable = [
    'sku_unit' => [
      [
        'product.unit_id',
        '=',
        'sku_unit.id'
      ]
    ],
    'client' => [
      [
        'product.client_id',
        '=',
        'client.id'
      ]
    ],
    'inventory' => [
      [
        'product.id',
        '=',
        'inventory.product_id'
      ]
    ]
  ];

  protected function onWhere(): void {
    $user = User::getLoggedUser();
    if (! $user->isSystemAdmin())
      $this->where[] = [
        'product.client_id',
        '=',
        $user->client->id
      ];

    if (isset($this->data['code']) && $this->data['code'] != '')
      $this->where[] = [
        'product.code',
        'like',
        '%' . $this->data['code'] . '%'
      ];

    if (isset($this->data['name']) && $this->data['name'] != '')
      $this->where[] = [
        'product.name',
        'like',
        '%' . $this->data['name'] . '%'
      ];

    if (isset($this->data['unit_id']) && $this->data['unit_id'] != '' && $this->data['unit_id'] != '0')
      $this->where[] = [
        'product.unit_id',
        '=',
        intval($this->data['client_id'])
      ];

    if (isset($this->data['client_id']) && $this->data['client_id'] != '' && $this->data['client_id'] != '0')
      $this->where[] = [
        'product.client_id',
        '=',
        intval($this->data['client_id'])
      ];
  }
}
