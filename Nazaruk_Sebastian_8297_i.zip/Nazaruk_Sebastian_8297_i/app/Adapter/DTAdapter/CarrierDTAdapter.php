<?php
namespace App\Adapter\DTAdapter;

use App\Adapter\Adapter;

class CarrierDTAdapter extends Adapter {

  protected $columns = [
    'id',
    'code',
    'name'
  ];

  protected $table = 'carrier';
}
