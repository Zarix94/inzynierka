<?php
namespace App\Adapter\DTAdapter;

use App\Adapter\Adapter;

class StatusDTAdapter extends Adapter {

  protected $columns = [
    's1.id',
    's1.code',
    's1.name',
    's1.type',
    'status.name AS next_status'
  ];

  protected $alias = 's1';

  protected $table = 'status AS s1';

  protected $joinTable = [
    'status' => [
      [
        's1.status_after_id',
        '=',
        'status.id'
      ]
    ]
  ];

  protected function onDataReady(&$data): void {
    foreach ($data as $row)
      $row->type = $row->type == '1' ? 'Awizacje dostaw' : 'Awizacje wysyłki';
  }
}
