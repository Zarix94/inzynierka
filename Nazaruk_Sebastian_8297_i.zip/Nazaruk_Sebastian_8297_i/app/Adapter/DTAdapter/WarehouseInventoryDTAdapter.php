<?php
namespace App\Adapter\DTAdapter;

use App\Adapter\Adapter;

class WarehouseInventoryDTAdapter extends Adapter {

  protected $columns = [
    'product.id',
    'product.code',
    'product.name',
    'sku_unit.name AS unit',
    'client.name as client',
    'sku_condition.name as condition'
  ];

  protected $table = 'product';

  protected $sum = [
    'inventory.quantity' => 'quantity'
  ];

  protected $groupBy = [
    'product.id',
    'product.code',
    'product.name',
    'sku_unit.name',
    'client.name',
    'sku_condition.name'
  ];

  protected $joinTable = [
    'sku_unit' => [
      [
        'product.unit_id',
        '=',
        'sku_unit.id'
      ]
    ],
    'client' => [
      [
        'product.client_id',
        '=',
        'client.id'
      ]
    ],
    'inventory' => [
      [
        'product.id',
        '=',
        'inventory.product_id'
      ]
    ],
    'sku_condition' => [
      [
        'inventory.condition_id',
        '=',
        'sku_condition.id'
      ]
    ]
  ];

  protected function onWhere(): void {
    $warehouseId = isset($this->data['id']) ? intval($this->data['id']) : - 1;
    $this->where[] = [
      'inventory.warehouse_id',
      '=',
      $warehouseId
    ];
  }
}
