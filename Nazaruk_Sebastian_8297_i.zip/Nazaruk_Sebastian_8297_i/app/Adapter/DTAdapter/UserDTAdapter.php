<?php
namespace App\Adapter\DTAdapter;

use App\Adapter\Adapter;
use App\Models\User;

class UserDTAdapter extends Adapter {

  protected $columns = [
    'users.id',
    'user_role.name as role',
    'client.name as client',
    'users.login',
    'users.email',
    'users.first_name',
    'users.last_name',
    'users.last_login',
    'users.last_bad_login'
  ];

  protected $table = 'users';

  protected $joinTable = [
    'user_role' => [
      [
        'users.role_id',
        '=',
        'user_role.id'
      ]
    ],
    'client' => [
      [
        'users.client_id',
        '=',
        'client.id'
      ]
    ]
  ];

  protected function onDataReady(&$data): void {
    foreach ($data as $row) {
      if ($row->last_login != '')
        $row->last_login = date('Y-m-d H:i:s', strtotime($row->last_login));

      if ($row->last_bad_login != '')
        $row->last_bad_login = date('Y-m-d H:i:s', strtotime($row->last_bad_login));
    }
  }

  protected function onWhere(): void {
    $user = User::getLoggedUser();
    if (! $user->isSystemAdmin())
      $this->where[] = [
        'users.client_id',
        '=',
        $user->client->id
      ];
  }
}
