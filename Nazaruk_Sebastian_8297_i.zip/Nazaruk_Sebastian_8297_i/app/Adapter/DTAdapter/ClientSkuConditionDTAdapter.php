<?php
namespace App\Adapter\DTAdapter;

use App\Adapter\Adapter;
use App\HtmlGenerator\Inputs\Checkbox;
use Illuminate\Support\Facades\DB;
use App\Models\User;

class ClientSkuConditionDTAdapter extends Adapter {

  protected $columns = [
    'sku_condition.id',
    'sku_condition.code',
    'sku_condition.name',
    'client_sku_condition.sku_condition_id as assign'
  ];

  protected $table = 'sku_condition';

  protected function onRequest(): void {
    $joinConditions = [];
    $joinConditions[] = [
      'sku_condition.id',
      '=',
      'client_sku_condition.sku_condition_id'
    ];

    $clientId = isset($this->data['id']) ? intval($this->data['id']) : - 1;
    $joinConditions[] = [
      'client_sku_condition.client_id',
      '=',
      DB::raw(DB::connection()->getPdo()->quote($clientId))
    ];

    $this->joinTable['client_sku_condition'] = $joinConditions;
  }

  protected function onWhere(): void {
    $user = User::getLoggedUser();
    if (! $user->isSystemAdmin())
      $this->where[] = [
        'client_sku_condition.client_id',
        '=',
        $user->client->id
      ];
  }

  protected function onDataReady(&$data): void {
    $user = User::getLoggedUser();

    foreach ($data as &$row) {
      if ($user->isSystemAdmin()) {
        $checkbox = new Checkbox('cbConditionToClient' . $row->id, '', $row->id);
        if ($row->assign !== null)
          $checkbox->setValue('on');
        $checkbox->setWithLabel(false);
        $checkbox->setClass('assign-condition');
        $row->assign = $checkbox->generateHtml();
      } else
        $row->assign = $row->assign !== null ? 'Tak' : 'Nie';
    }
  }
}
