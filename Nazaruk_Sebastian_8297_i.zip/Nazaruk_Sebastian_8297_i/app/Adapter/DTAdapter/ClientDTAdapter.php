<?php
namespace App\Adapter\DTAdapter;

use App\Adapter\Adapter;
use App\Models\User;
use App\Models\UserRole;

class ClientDTAdapter extends Adapter {

  protected $columns = [
    'client.id',
    'client.code',
    'client.name',
    'client.nip',
    'client.contact_email',
    'client.contact_number',
    'country.name as country',
    'client.city',
    'client.address',
    'client.postcode',
    'client.description'
  ];

  protected $table = 'client';

  protected $joinTable = [

    'country' => [
      [
        'client.country_id',
        '=',
        'country.id'
      ]
    ]
  ];

  protected function onWhere(): void {
    $user = User::getLoggedUser();
    if (! $user->isSystemAdmin())
      $this->where[] = [
        'client.id',
        '=',
        $user->client->id
      ];

    if (isset($this->data['code']) && $this->data['code'] != '')
      $this->where[] = [
        'client.code',
        'like',
        '%' . $this->data['code'] . '%'
      ];

    if (isset($this->data['name']) && $this->data['name'] != '')
      $this->where[] = [
        'client.name',
        'like',
        '%' . $this->data['name'] . '%'
      ];

    if (isset($this->data['nip']) && $this->data['nip'] != '')
      $this->where[] = [
        'client.nip',
        'like',
        '%' . $this->data['nip'] . '%'
      ];

    if (isset($this->data['contact_email']) && $this->data['contact_email'] != '')
      $this->where[] = [
        'client.contact_email',
        'like',
        '%' . $this->data['contact_email'] . '%'
      ];

    if (isset($this->data['contact_number']) && $this->data['contact_number'] != '')
      $this->where[] = [
        'client.contact_number',
        'like',
        '%' . $this->data['contact_number'] . '%'
      ];

    if (isset($this->data['city']) && $this->data['city'] != '')
      $this->where[] = [
        'client.city',
        'like',
        '%' . $this->data['city'] . '%'
      ];

    if (isset($this->data['address']) && $this->data['address'] != '')
      $this->where[] = [
        'client.address',
        'like',
        '%' . $this->data['address'] . '%'
      ];

    if (isset($this->data['postcode']) && $this->data['postcode'] != '')
      $this->where[] = [
        'client.postcode',
        'like',
        '%' . $this->data['postcode'] . '%'
      ];

    if (isset($this->data['country_id']) && $this->data['country_id'] != '' && $this->data['country_id'] != '0')
      $this->where[] = [
        'client.country_id',
        '=',
        intval($this->data['country_id'])
      ];
  }
}
