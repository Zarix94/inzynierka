<?php
namespace App\Adapter\DTAdapter;

use App\Adapter\Adapter;
use App\Models\User;
use Illuminate\Support\Facades\DB;

class WarehouseDTAdapter extends Adapter {

  protected $columns = [
    'warehouse.id',
    'warehouse.code',
    'warehouse.name'
  ];

  protected $table = 'warehouse';

  private function joinTable(int $clientId): void {
    $joinConditions = [];
    $joinConditions[] = [
      'warehouse.id',
      '=',
      'client_warehouse.warehouse_id'
    ];

    $joinConditions[] = [
      'client_warehouse.client_id',
      '=',
      DB::raw(DB::connection()->getPdo()->quote($clientId))
    ];

    $this->joinTable['client_warehouse'] = $joinConditions;
  }

  private function addCondition(int $clientId): void {
    $this->where[] = [
      'client_warehouse.client_id',
      '=',
      $clientId
    ];
  }

  protected function onRequest(): void {
    $user = User::getLoggedUser();
    if (! $user->isSystemAdmin()) {
      $this->joinTable($user->client->id);
      $this->addCondition($user->client->id);
    }
  }

  protected function onWhere(): void {
    if (isset($this->data['code']) && $this->data['code'] != '')
      $this->where[] = [
        'warehouse.code',
        'like',
        '%' . $this->data['code'] . '%'
      ];

    if (isset($this->data['name']) && $this->data['name'] != '')
      $this->where[] = [
        'warehouse.name',
        'like',
        '%' . $this->data['name'] . '%'
      ];
  }
}
