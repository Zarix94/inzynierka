<?php
namespace App\Adapter\DTAdapter;

use App\Adapter\Adapter;
use App\HtmlGenerator\Inputs\Checkbox;
use Illuminate\Support\Facades\DB;
use App\Models\User;

class ClientCarrierDTAdapter extends Adapter {

  protected $columns = [
    'carrier.id',
    'carrier.code',
    'carrier.name',
    'client_carrier.carrier_id as assign'
  ];

  protected $table = 'carrier';

  protected function onRequest(): void {
    $joinConditions = [];
    $joinConditions[] = [
      'carrier.id',
      '=',
      'client_carrier.carrier_id'
    ];

    $clientId = isset($this->data['id']) ? intval($this->data['id']) : - 1;
    $joinConditions[] = [
      'client_carrier.client_id',
      '=',
      DB::raw(DB::connection()->getPdo()->quote($clientId))
    ];

    $this->joinTable['client_carrier'] = $joinConditions;
  }

  protected function onWhere(): void {
    $user = User::getLoggedUser();
    if (! $user->isSystemAdmin())
      $this->where[] = [
        'client_carrier.client_id',
        '=',
        $user->client->id
      ];
  }

  protected function onDataReady(&$data): void {
    $user = User::getLoggedUser();

    foreach ($data as &$row) {
      if ($user->isSystemAdmin()) {
        $checkbox = new Checkbox('cbCarrierToClient' . $row->id, '', $row->id);
        if ($row->assign !== null)
          $checkbox->setValue('on');
        $checkbox->setWithLabel(false);
        $checkbox->setClass('assign-carrier');
        $row->assign = $checkbox->generateHtml();
      } else
        $row->assign = $row->assign !== null ? 'Tak' : 'Nie';
    }
  }
}
