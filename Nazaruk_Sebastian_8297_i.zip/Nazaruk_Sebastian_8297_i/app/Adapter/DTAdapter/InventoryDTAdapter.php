<?php
namespace App\Adapter\DTAdapter;

use App\Adapter\Adapter;
use Illuminate\Foundation\Auth\User;

class ProductDTAdapter extends Adapter {

  protected $columns = [
    'product.id',
    'product.code',
    'product.name',
    'sku_unit.name AS unit',
    'client.name as client'
  ];

  protected $table = 'product';

  protected $sum = [
    'inventory.quantity' => 'quantity'
  ];

  protected $groupBy = [
    'product.id',
    'product.code',
    'product.name',
    'sku_unit.name',
    'client.name'
  ];

  protected $joinTable = [
    'sku_unit' => [
      [
        'product.unit_id',
        '=',
        'sku_unit.id'
      ]
    ],
    'client' => [
      [
        'product.client_id',
        '=',
        'client.id'
      ]
    ],
    'inventory' => [
      [
        'product.id',
        '=',
        'inventory.product_id'
      ]
    ]
  ];

  private function addCondition(int $clientId): void {
    $this->where[] = [
      'product.client_id',
      '=',
      $clientId
    ];
  }

  protected function onRequest(): void {
    $user = User::getLoggedUser();
    if (! $user->isSystemAdmin())
      $this->addCondition($user->client->id);
  }
}
