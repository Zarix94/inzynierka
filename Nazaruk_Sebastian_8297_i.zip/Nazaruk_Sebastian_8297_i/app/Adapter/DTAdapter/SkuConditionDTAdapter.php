<?php
namespace App\Adapter\DTAdapter;

use App\Adapter\Adapter;

class SkuConditionDTAdapter extends Adapter {

  protected $columns = [
    'id',
    'code',
    'name'
  ];

  protected $table = 'sku_condition';
}
