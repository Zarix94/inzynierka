<?php
namespace App\Adapter\DTAdapter;

use App\Adapter\Adapter;

class SkuUnitDTAdapter extends Adapter {

  protected $columns = [
    'id',
    'code',
    'name'
  ];

  protected $table = 'sku_unit';
}
