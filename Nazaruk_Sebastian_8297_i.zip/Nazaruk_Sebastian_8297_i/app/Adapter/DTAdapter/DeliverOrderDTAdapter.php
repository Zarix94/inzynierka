<?php
namespace App\Adapter\DTAdapter;

use App\Adapter\Adapter;
use App\Models\User;

class DeliverOrderDTAdapter extends Adapter {

  protected $columns = [
    'deliver_order.id',
    'deliver_order.order_date',
    'client.name as client',
    'warehouse.name as warehouse',
    'carrier.name as carrier',
    'deliver_order.contractor_name',
    'country.name as country',
    'deliver_order.city',
    'deliver_order.address',
    'deliver_order.postcode',
    'status.name as status'
  ];

  protected $table = 'deliver_order';

  protected $joinTable = [
    'client' => [
      [
        'deliver_order.client_id',
        '=',
        'client.id'
      ]
    ],
    'warehouse' => [
      [
        'deliver_order.warehouse_id',
        '=',
        'warehouse.id'
      ]
    ],
    'carrier' => [
      [
        'deliver_order.carrier_id',
        '=',
        'carrier.id'
      ]
    ],
    'country' => [
      [
        'deliver_order.country_id',
        '=',
        'country.id'
      ]
    ],
    'status' => [
      [
        'deliver_order.status_id',
        '=',
        'status.id'
      ]
    ]
  ];

  protected function onWhere(): void {
    $user = User::getLoggedUser();
    if (! $user->isSystemAdmin())
      $this->where[] = [
        'deliver_order.client_id',
        '=',
        $user->client->id
      ];
  }
}
