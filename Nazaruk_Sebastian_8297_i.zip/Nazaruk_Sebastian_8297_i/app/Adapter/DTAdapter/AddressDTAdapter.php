<?php
namespace App\Adapter\DTAdapter;

use App\Adapter\Adapter;
use App\Models\User;

class AddressDTAdapter extends Adapter {

  protected $columns = [
    'address.id',
    'client.name as client',
    'address.code',
    'address.name',
    'address.contact_email',
    'address.contact_number',
    'country.name as country',
    'address.city',
    'address.address',
    'address.postcode',
    'address.description'
  ];

  protected $table = 'address';

  protected $joinTable = [
    'country' => [
      [
        'address.country_id',
        '=',
        'country.id'
      ]
    ],
    'client' => [
      [
        'address.client_id',
        '=',
        'client.id'
      ]
    ]
  ];

  protected function onWhere(): void {
    $user = User::getLoggedUser();
    if (! $user->isSystemAdmin())
      $this->where[] = [
        'address.client_id',
        '=',
        $user->client->id
      ];
  }
}
