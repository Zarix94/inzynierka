<?php
namespace App\Adapter\DTAdapter;

use App\Adapter\Adapter;

class CountryDTAdapter extends Adapter {

  protected $columns = [
    'id',
    'code',
    'name'
  ];

  protected $table = 'country';
}
