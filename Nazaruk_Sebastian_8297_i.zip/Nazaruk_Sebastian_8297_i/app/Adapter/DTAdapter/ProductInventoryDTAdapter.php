<?php
namespace App\Adapter\DTAdapter;

use App\Adapter\Adapter;

class ProductInventoryDTAdapter extends Adapter {

  protected $columns = [
    'inventory.id',
    'warehouse.name as warehouse',
    'sku_condition.name as condition',
    'inventory.quantity'
  ];

  protected $sum = [];

  protected $table = 'inventory';

  protected $joinTable = [
    'warehouse' => [
      [
        'inventory.warehouse_id',
        '=',
        'warehouse.id'
      ]
    ],
    'sku_condition' => [
      [
        'inventory.condition_id',
        '=',
        'sku_condition.id'
      ]
    ]
  ];

  protected function onWhere(): void {
    $productId = isset($this->data['id']) ? intval($this->data['id']) : - 1;
    $this->where[] = [
      'inventory.product_id',
      '=',
      $productId
    ];
  }
}
