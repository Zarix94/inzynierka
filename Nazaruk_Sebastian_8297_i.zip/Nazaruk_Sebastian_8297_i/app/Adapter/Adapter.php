<?php
namespace App\Adapter;

use Illuminate\Support\Facades\DB;

abstract class Adapter {

  protected $data = [];

  public function __construct(array $data = []) {
    $this->data = $data;
  }

  protected $limit = 50;

  protected $columns = [];

  /*
   *
   * 'column name' => 'alias'
   * ]
   */
  protected $sum = [];

  protected $groupBy = [];

  protected $includeDeleted = false;

  protected $table = '';

  /*
   * tablename=> [
   * 0 = '1kolumna',
   * 1 = 'sposób porównaia',
   * 2 = '2kolumna'
   * ]
   */
  protected $joinTable = [];

  /*
   * [
   * 0 = '1kolumna',
   * 1 = 'sposób porównaia',
   * 2 = '2kolumna'
   * ]
   */
  protected $alias = '';

  protected $where = [];

  protected function onRequest(): void {}

  protected function onWhere(): void {}

  protected function onDataReady(&$data): void {}

  public function get(): array {
    $this->onRequest();
    $db = DB::table($this->table);
    $tableName = $this->alias !== '' ? $this->alias : $this->table;

    foreach ($this->joinTable as $table => $conditions)
      $db->leftJoin($table, function ($join) use ($conditions) {
        foreach ($conditions as $condition)
          $join->on($condition[0], $condition[1], $condition[2]);
      });

    $db->select($this->columns);
    foreach ($this->sum as $sumColumn => $alias)
      $db->selectRaw('COALESCE(SUM(' . $sumColumn . '), 0) as ' . $alias);

    $db->orderBy($tableName . '.id', 'asc');
    /*
     * if ($this->limit > - 1)
     * $db->take($this->limit);
     */
    if ($this->includeDeleted === false)
      $db->whereNull($tableName . '.deleted_at');

    $this->onWhere();
    foreach ($this->where as $condtion)
      $db->where($condtion[0], $condtion[1], $condtion[2]);

    if (count($this->groupBy) > 0)
      $db->groupBy($this->groupBy);

    $data = $db->get();
    $result = $data->all();

    $this->onDataReady($data);

    return $result;
  }
}
