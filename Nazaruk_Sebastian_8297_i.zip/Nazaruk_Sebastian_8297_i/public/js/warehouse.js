var warehouse = new ModelObject('Warehouse');

function initialize() {
  tblWarehouseData = {
    id : 'tblWarehouse',
    adapter : 'WarehouseDTAdapter'
  };

  window['tblWarehouse'] = new DataTableObj(tblWarehouseData);
  tblWarehouse.init();

  tblWarehouseInventoryData = {
    id : 'tblWarehouseInventory',
    adapter : 'WarehouseInventoryDTAdapter'
  };

  window['tblWarehouseInventory'] = new DataTableObj(tblWarehouseInventoryData);
  tblWarehouseInventory.init({
    id : warehouse.id
  });

  warehouse.onSaveFunction = warehouseOnSave;
  warehouse.onRemoveFunction = warehouseOnSave;
  warehouse.onGet = warehouseOnGet;

}

function loadComplete() {
  initialize();
  $('#tabs-warehouse').tabs({
    activate : function(event, ui) {
      tblWarehouseInventory.dataTable.draw();
    }
  });

  $('#btSave').click(btSaveOnClick);
  $('#btNew').click(btNewOnClick);
  $('#btDelete').click(btDeleteOnClick);

  $('#clearFilter').click(clearFilters);
  $('#applyFilter').click(applyFilters);
}

function warehouseOnSave(result) {
  tblWarehouse.refresh();
}

function btSaveOnClick() {
  var result = warehouse.save('warehouse-form');

}

function btNewOnClick() {
  warehouse.reset('warehouse-form');
}

function tblWarehouseOnRowSelected(data) {
  warehouse.get(data[0], 'warehouse-form');
}

function btDeleteOnClick() {
  client.remove('client-form');
}

function warehouseOnGet() {
  tblWarehouseInventory.refresh({
    id : warehouse.id
  });
}

function clearFilters() {
  $('.filter-input').val('');
  $('.filter-select').val('')

  tblWarehouse.refresh({});

}

function applyFilters() {
  var filters = {};

  $('.filter-input').each(function(idx, elm) {
    var value = $(this).val();
    if (value != '') {
      var dataId = $(this).attr('data-id');

      filters[dataId] = value;
    }
  });

  $('.filter-select').each(function(idx, elm) {
    var value = $(this).val();

    if (value != '' && value != '0') {
      var dataId = $(this).attr('data-id');
      filters[dataId] = value;
    }
  });

  tblWarehouse.refresh(filters);
}