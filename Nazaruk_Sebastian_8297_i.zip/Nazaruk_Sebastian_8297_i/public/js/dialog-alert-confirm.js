function DialogAlertConfirm(msg, onOkHandler, modal, onCancel, val) {

  var id = parseInt(Math.random() * 1e+6);

  $('body')
      .append(
          '<div id="'
              + id
              + '"><span class="ui-icon ui-icon-alert" style="float: left; margin: 0 7px 40px 0;"></span>'
              + $('<div/>').html(msg).text() + '</div>');

  this.onCancel = function() {
    $(this).dialog('close');
    if (onCancel != null)
      onCancel();
  }

  this.onOk = function(e) {
    $(this).dialog('close');
    if (val == null)
      onOkHandler();
    else
      onOkHandler(val);
  }

  var buttons = new Object();
  buttons['Anuluj'] = this.onCancel;
  buttons['OK'] = this.onOk;

  $('#' + id).dialog({
    resizable : false,
    title : 'Potwierdzenie',
    show : {
      effect : 'fade',
      duration : 150
    },
    hide : {
      effect : 'fade',
      duration : 150
    },
    modal : modal == null ? true : modal,
    buttons : buttons,
    close : function() {
      $(this).remove();
    }
  });
}
