var client = null

function initialize() {
  client = new ModelObject('Client');

  tblClientData = {
    id : 'tblClient',
    adapter : 'ClientDTAdapter'
  };

  window['tblClient'] = new DataTableObj(tblClientData);
  tblClient.init();

  tblClientWarehouseData = {
    id : 'tblClientWarehouse',
    adapter : 'ClientWarehouseDTAdapter'
  };

  window['tblClientWarehouse'] = new DataTableObj(tblClientWarehouseData);
  tblClientWarehouse.init({
    id : client.id
  }, 230);

  tblClientSkuConditionData = {
    id : 'tblClientSkuCondition',
    adapter : 'ClientSkuConditionDTAdapter'
  };

  window['tblClientSkuCondition'] = new DataTableObj(tblClientSkuConditionData);
  tblClientSkuCondition.init({
    id : client.id
  }, 230);

  tblClientCarrierData = {
    id : 'tblClientCarrier',
    adapter : 'ClientCarrierDTAdapter'
  };

  window['tblClientCarrier'] = new DataTableObj(tblClientCarrierData);
  tblClientCarrier.init({
    id : client.id
  }, 230);

  client.onSaveFunction = clientOnSave;
  client.onRemoveFunction = clientOnSave;
  client.onGet = clientOnGet;

}

function loadComplete() {
  $('#tabs-client').tabs({
    activate : function(event, ui) {
      tblClientWarehouse.dataTable.draw();
      tblClientSkuCondition.dataTable.draw();
      tblClientCarrier.dataTable.draw();
    }
  });

  initialize();
  $('#btSave').click(btSaveOnClick);
  $('#btNew').click(btNewOnClick);
  $('#btDelete').click(btDeleteOnClick);
  $('#btAssignWarehouseToClient').click(btAssignWarehouseToClientOnClick);
  $('#btAssignConditionToClient').click(btAssignConditionToClientOnClick);
  $('#btAssignCarrierToClient').click(btAssignCarrierToClientOnClick);
  $('#clearFilter').click(clearFilters);
  $('#applyFilter').click(applyFilters);
}

function clientOnSave(result) {
  tblClient.refresh();
}

function btSaveOnClick() {
  var result = client.save('client-form');

}

function btNewOnClick() {
  client.reset('client-form');
}

function tblClientOnRowSelected(data) {
  client.get(data[0], 'client-form');
}

function btDeleteOnClick() {
  client.remove('client-form');
}

function clientOnGet() {
  tblClientWarehouse.refresh({
    id : client.id
  });

  tblClientSkuCondition.refresh({
    id : client.id
  });

  tblClientCarrier.refresh({
    id : client.id
  });
}

function btAssignWarehouseToClientOnClick() {
  if (client.id == -1) {
    new DialogAlert('Wybierz klienta');
    return;
  }

  var warehouses = []
  $($('.assign-warehouse')).each(function(idx, elm) {
    if ($(elm)[0].checked)
      warehouses.push($(elm).attr('data-id'));
  });

  var postData = {
    '_token' : getCSRFToken(),
    'client_id' : client.id,
    'warehouses' : warehouses
  }

  $.post('assing-warehouse', postData, function(res) {
    new DialogAlert('Przypisano');

  });

}

function btAssignConditionToClientOnClick() {
  if (client.id == -1) {
    new DialogAlert('Wybierz klienta');
    return;
  }

  var conditions = []
  $($('.assign-condition')).each(function(idx, elm) {
    if ($(elm)[0].checked)
      conditions.push($(elm).attr('data-id'));
  });

  var postData = {
    '_token' : getCSRFToken(),
    'client_id' : client.id,
    'conditions' : conditions
  }

  $.post('assing-condition', postData, function(res) {
    new DialogAlert('Przypisano');
  });

}

function btAssignCarrierToClientOnClick() {
  if (client.id == -1) {
    new DialogAlert('Wybierz klienta');
    return;
  }

  var carriers = []
  $($('.assign-carrier')).each(function(idx, elm) {
    if ($(elm)[0].checked)
      carriers.push($(elm).attr('data-id'));
  });

  var postData = {
    '_token' : getCSRFToken(),
    'client_id' : client.id,
    'carriers' : carriers
  }

  $.post('assing-carrier', postData, function(res) {
    new DialogAlert('Przypisano');
  });

}

function clearFilters() {
  $('.filter-input').val('');
  $('.filter-select').val('');
  tblClient.refresh({});
}

function applyFilters() {
  var filters = {};

  $('.filter-input').each(function(idx, elm) {
    var value = $(this).val();
    if (value != '') {
      var dataId = $(this).attr('data-id');

      filters[dataId] = value;
    }
  });

  $('.filter-select').each(function(idx, elm) {
    var value = $(this).val();

    if (value != '' && value != '0') {
      var dataId = $(this).attr('data-id');
      filters[dataId] = value;
    }
  });

  tblClient.refresh(filters);
}
