function setInputError(inputId, msg) {
  var selector = $('#' + inputId);

  selector.addClass('is-invalid');

  if (msg != ''){
    $('#' + inputId).attr('title', msg);
    $('#' + inputId).tooltip()
  } else
    $('#' + inputId + '-invalid-msg').hide();
}

function removeInputError(inputId) {
  var selector = $('#' + inputId);

  selector.removeClass('is-invalid');
  $('#' + inputId).tooltip('dispose')

  $('#' + inputId + '-invalid-msg').text('');
}

function getCSRFToken() {
  return $('meta[name="csrf_token"]').attr('content')
}

function clearErrors(formId){
  var selector = $('#' + formId + ' .form-control');
  selector.each(function(idx, elm){
    var inputId = $(elm).attr('id');

    removeInputError(inputId);
  });
  
}

function handleErrors(errors, formId) {
  clearErrors(formId);
  var msg = '';
  
  for (const [key, value] of Object.entries(errors)) {
    if(key == 'message')
    msg += value + ' ';
    else {
      var selector = $('#' + formId + ' .form-control[data-id="'+key+'"]');
      var inputId = selector.attr('id');
      setInputError(inputId, value);
    } 
  }
  
  if(msg != '')
    new DialogAlert(msg);
}

$(document).ready(function() {
  if (window['initMenu'])
    initMenu();

  if (window['loadComplete'])
    loadComplete();
});
