function DataTableObj(data) {
  this.id = data.id;
  this.adapter = data.adapter;
  this.dataTable;
  this.columns;
  this.onRowSelectedFunction = null;

  function getColumns(id) {
    var headers = $('#' + id + ' th');
    var columns = [];
    $(headers).each(function(idx, elm) {
      columns.push($(elm).attr('data-id'));
    });

    return columns;
  }

  function generateRows(columns, data) {
    var rows = [];

    $(data).each(function(idx, elm) {
      var rowData = [];
      $(columns).each(function(columnIdx, columnElm) {
        rowData.push(elm[columnElm]);
      });
      rows.push(rowData);
    });

    return rows;
  }

  this.init = function initTable(data, scrollY = 400) {
    var postData = {
      '_token' : getCSRFToken(),
      'adapter' : this.adapter,
      'data' : data
    }

    var self = this;

    $.post('get-for-table-adapter', postData, function(res) {
      var rows = generateRows(self.columns, res);

      self.dataTable = $('#' + self.id).DataTable({
        'data' : rows,
        'lengthChange' : false,
        'searching' : false,
        'pageLength' : 50,
        language : {
          url : 'http://cdn.datatables.net/plug-ins/1.10.22/i18n/Polish.json'
        },
        'scrollY' : scrollY + 'px',
        'columnDefs' : [
          {
            'targets' : [
              0
            ],
            'visible' : false
          }
        ]
      });

      $('#' + self.id + ' tbody').on('click', 'tr', function() {
        var tableData = self.dataTable.row(this).data();
        if (window[self.id + 'OnRowSelected'])
          window[self.id + 'OnRowSelected'](tableData);
      });

    });
  }

  this.refresh = function(data) {
    var postData = {
      '_token' : getCSRFToken(),
      'adapter' : this.adapter,
      'data' : data
    }

    var self = this;

    $.post('get-for-table-adapter', postData, function(res) {
      var rows = generateRows(self.columns, res);
      self.dataTable.clear();
      self.dataTable.rows.add(rows);
      self.dataTable.draw();

    });
  }

  this.columns = getColumns(this.id);

}
