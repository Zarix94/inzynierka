function initMenu() {
  $('nav').children().each(function(idx, elm) {
    $(elm).click(function() {
      window.location.href = $(this).attr('data-target');
    });

  });

}