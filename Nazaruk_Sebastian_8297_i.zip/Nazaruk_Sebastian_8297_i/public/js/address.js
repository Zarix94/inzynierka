var address = new ModelObject('Address');

function initialize() {
  tblAddressData = {
    id : 'tblAddress',
    adapter : 'AddressDTAdapter'
  };

  window['tblAddress'] = new DataTableObj(tblAddressData);
  tblAddress.init();

  address.onSaveFunction = addressOnSave;
  address.onRemoveFunction = addressOnSave;
}

function loadComplete() {
  initialize();
  $('#btSave').click(btSaveOnClick);
  $('#btNew').click(btNewOnClick);
  $('#btDelete').click(btDeleteOnClick);
}

function addressOnSave(result) {
  tblAddress.refresh();
}

function btSaveOnClick() {
  var result = address.save('address-form');

}

function btNewOnClick() {
  address.reset('address-form');
}

function tblAddressOnRowSelected(data) {
  address.get(data[0], 'address-form');
}

function btDeleteOnClick() {
  client.remove('client-form');
}