var product = new ModelObject('Product');

function initialize() {
  window['tblProduct'] = new DataTableObj({
    id : 'tblProduct',
    adapter : 'ProductDTAdapter'
  });
  tblProduct.init();

  window['tblProductInventory'] = new DataTableObj({
    id : 'tblProductInventory',
    adapter : 'ProductInventoryDTAdapter'
  });

  tblProductInventory.init();

  product.onSaveFunction = productOnSave;
  product.onRemoveFunction = productOnSave;
  product.onGet = productOnGet;
  product.onReset = productOnReset;

}

function loadComplete() {
  $('#tabs-product').tabs({
    activate : function(event, ui) {
      tblProductInventory.dataTable.draw()
    }
  });

  initialize();

  $('#btSave').click(btSaveOnClick);
  $('#btNew').click(btNewOnClick);
  $('#btDelete').click(btDeleteOnClick);
  $('#btAssignCarrierToClient').click(btAssignCarrierToClientOnClick);
  $('#clearFilter').click(clearFilters);
  $('#applyFilter').click(applyFilters);
}

function productOnSave(result) {
  tblProduct.refresh({
    id : product.id
  });
}

function btSaveOnClick() {
  var result = product.save('product-form');
}

function btNewOnClick() {
  product.reset('product-form');
}

function tblProductOnRowSelected(data) {
  product.get(data[0], 'product-form');
}

function productOnGet() {
  tblProductInventory.refresh({
    id : product.id
  });
}

function btDeleteOnClick() {
  client.remove('client-form');
}

function productOnReset() {
  tblProductInventory.refresh({
    id : product.id
  });
}

function clearFilters() {
  $('.filter-input').val('');
  $('.filter-select').val('')

  tblProduct.refresh({});

}

function applyFilters() {
  var filters = {};

  $('.filter-input').each(function(idx, elm) {
    var value = $(this).val();
    if (value != '') {
      var dataId = $(this).attr('data-id');

      filters[dataId] = value;
    }
  });

  $('.filter-select').each(function(idx, elm) {
    var value = $(this).val();

    if (value != '' && value != '0') {
      var dataId = $(this).attr('data-id');
      filters[dataId] = value;
    }
  });

  tblProduct.refresh(filters);
}