//kraje

var country = new ModelObject('Country');

function countryOnSave(result) {
  tblCountry.refresh();
}

function btSaveCountryOnClick() {
  var result = country.save('country-form');
}

function btNewCountryOnClick() {
  country.reset('country-form');
}

function tblCountryOnRowSelected(data) {
  country.get(data[0], 'country-form');
}

function btDeleteCountryOnClick() {
  country.remove('country-form');
}

function initializeCountryTab() {
  window['tblCountry'] = new DataTableObj({
    id : 'tblCountry',
    adapter : 'CountryDTAdapter'
  });

  tblCountry.init();
  country.onSaveFunction = countryOnSave;
  country.onRemoveFunction = countryOnSave;

  $('#btSaveCountry').click(btSaveCountryOnClick);
  $('#btNewCountry').click(btNewCountryOnClick);
  $('#btDeleteCountry').click(btDeleteCountryOnClick);
}

// kondycje towarów
var skuCondition = new ModelObject('SkuCondition');

function skuConditionOnSave(result) {
  tblSkuCondition.refresh();
}

function btSaveSkuConditionOnClick() {
  var result = skuCondition.save('sku-condition-form');
}

function btNewSkuConditionOnClick() {
  skuCondition.reset('sku-condition-form');
}

function tblSkuConditionOnRowSelected(data) {
  skuCondition.get(data[0], 'sku-condition-form');
}

function btDeleteSkuConditionOnClick() {
  skuCondition.remove('sku-condition-form');
}

function initializeSkuConditionTab() {
  window['tblSkuCondition'] = new DataTableObj({
    id : 'tblSkuCondition',
    adapter : 'SkuConditionDTAdapter'
  });

  tblSkuCondition.init();
  skuCondition.onSaveFunction = skuConditionOnSave;
  skuCondition.onRemoveFunction = skuConditionOnSave;

  $('#btSaveSkuCondition').click(btSaveSkuConditionOnClick);
  $('#btNewSkuCondition').click(btNewSkuConditionOnClick);
  $('#btDeleteSkuCondition').click(btDeleteSkuConditionOnClick);
}

// przewoźnicy

var carrier = new ModelObject('Carrier');

function carrierOnSave(result) {
  tblCarrier.refresh();
}

function btSaveCarrierOnClick() {
  var result = carrier.save('carrier-form');
}

function btNewCarrierOnClick() {
  carrier.reset('carrier-form');
}

function tblSkuConditionOnRowSelected(data) {
  carrier.get(data[0], 'carrier-form');
}

function btDeleteCarrierOnClick() {
  carrier.remove('carrier-form');
}

function initializeCarrierTab() {
  window['tblCarrier'] = new DataTableObj({
    id : 'tblCarrier',
    adapter : 'CarrierDTAdapter'
  });

  tblCarrier.init();
  carrier.onSaveFunction = carrierOnSave;
  carrier.onRemoveFunction = carrierOnSave;

  $('#btSaveCarrier').click(btSaveCarrierOnClick);
  $('#btNewCarrier').click(btNewCarrierOnClick);
  $('#btDeleteCarrier').click(btDeleteCarrierOnClick);
}

// jednostki składowania
var skuUnit = new ModelObject('SkuUnit');

function skuUnitOnSave(result) {
  tblSkuUnit.refresh();
}

function btSaveSkuUnitOnClick() {
  var result = skuUnit.save('sku-unit-form');
}

function btNewSkuUnitOnClick() {
  skuUnit.reset('sku-unit-form');
}

function tblSkuUnitOnRowSelected(data) {
  skuUnit.get(data[0], 'sku-unit-form');
}

function btDeleteSkuUnitOnClick() {
  skuUnit.remove('sku-unit-form');
}

function initializeSkuUnitTab() {
  window['tblSkuUnit'] = new DataTableObj({
    id : 'tblSkuUnit',
    adapter : 'SkuUnitDTAdapter'
  });

  tblSkuUnit.init();
  skuUnit.onSaveFunction = skuUnitOnSave;
  skuUnit.onRemoveFunction = skuUnitOnSave;

  $('#btSaveSkuUnit').click(btSaveSkuUnitOnClick);
  $('#btNewSkuUnit').click(btNewSkuUnitOnClick);
  $('#btDeleteSkuUnit').click(btDeleteSkuUnitOnClick);
}

// statusy
var statusObj = new ModelObject('Status');

function statusOnSave(result) {
  tblStatus.refresh();
}

function btSaveStatusOnClick() {
  var result = statusObj.save('status-form');
}

function btNewStatusOnClick() {
  statusObj.reset('status-form');
}

function tblStatusOnRowSelected(data) {
  statusObj.get(data[0], 'status-form');
}

function btDeleteStatusOnClick() {
  statusObj.remove('status-form');
}

function initializeStatusTab() {
  window['tblStatus'] = new DataTableObj({
    id : 'tblStatus',
    adapter : 'StatusDTAdapter'
  });

  tblStatus.init();

  statusObj.onSaveFunction = statusOnSave;
  statusObj.onRemoveFunction = statusOnSave;

  $('#btSaveStatus').click(btSaveStatusOnClick);
  $('#btNewStatus').click(btNewStatusOnClick);
  $('#btDeleteStatus').click(btDeleteStatusOnClick);

}

function initialize() {
  initializeCountryTab();
  initializeSkuConditionTab();
  initializeCarrierTab();
  initializeSkuUnitTab()
  initializeStatusTab()

}

function loadComplete() {
  $('#tabs-dictionary').tabs({
    activate : function(event, ui) {
      tblCountry.dataTable.draw()
      tblSkuCondition.dataTable.draw()
      tblCarrier.dataTable.draw()
      tblSkuUnit.dataTable.draw()
      tblStatus.dataTable.draw();
    }
  });
  initialize();
}
