var deliverOrder = new ModelObject('DeliverOrder');
var deliverLine = new ModelObject('DeliverLine')
function initialize() {
  tblDeliverOrderData = {
    id : 'tblDeliverOrder',
    adapter : 'DeliverOrderDTAdapter'
  };

  window['tblDeliverOrder'] = new DataTableObj(tblDeliverOrderData);
  tblDeliverOrder.init([], 330);

  tblDeliverLineData = {
    id : 'tblDeliverLine',
    adapter : 'DeliverLineDTAdapter'
  };

  window['tblDeliverLine'] = new DataTableObj(tblDeliverLineData);
  tblDeliverLine.init({
    id : deliverOrder.id
  }, 230);

  deliverOrder.onSaveFunction = deliverOrderOnSave;
  deliverOrder.onRemoveFunction = deliverOrderOnSave;
  deliverOrder.onGet = deliverOnGet;
  deliverOrder.onReset = deliverOnReset;

  deliverLine.onSaveFunction = deliverLineOnSave;
  deliverLine.onRemoveFunction = deliverLineOnRemove;
  deliverLine.onReset = deliverLineOnReset;
}

function loadComplete() {
  $('#itOrderDate').datepicker();
  $('#tabs-order').tabs({
    activate : function(event, ui) {
      tblDeliverOrder.dataTable.draw()
    }
  });

  $('#tabs-deliver_order').tabs({
    activate : function(event, ui) {
      tblDeliverLine.dataTable.draw()

    }
  });

  initialize();

  $('#btSaveDeliver').click(btSaveDeliverOnClick);
  $('#btNewDeliver').click(btNewDeliverOnClick);
  $('#btDeleteDeliver').click(btDeleteDeliverOnClick);

  $('#btSaveDeliverLine').click(btSaveDeliverLineOnClick);
  $('#btNewDeliverLine').click(btNewDeliverLineOnClick);
  $('#btDeleteDeliverLine').click(btDeleteDeliverLineOnClick);
  $('#btRealizeOrder').click(btRealizeOrderOnClick)

  $('#itAddress').change(function() {
    var addressId = $(this).val();
    if (addressId != 0) {
      var postData = {
        '_token' : getCSRFToken(),
        'address_id' : addressId
      }

      $.post('get-addres-data', postData, function(data) {
        if (data.result == false)
          handleErrors(data.errors);
        else {
          $('#itContractorName').val(data.data.name);
          $('#itOrderCountry').val(data.data.country_id);
          $('#itOrderCity').val(data.data.city);
          $('#itOrderAddress').val(data.data.address);
          $('#itOrderPostCode').val(data.data.postcode);
        }
      });
    }
  });
}

function deliverOrderOnSave(result) {
  tblDeliverOrder.refresh();
  tblDeliverLine.refresh({
    id : deliverOrder.id
  });
}

function btSaveDeliverOnClick() {
  var result = deliverOrder.save('deliver-order-form');

}

function btNewDeliverOnClick() {
  deliverOrder.reset('deliver-order-form');
}

function tblDeliverOrderOnRowSelected(data) {
  deliverOrder.get(data[0], 'deliver-order-form');
}

function btDeleteDeliverOnClick() {
  deliverOrder.remove('deliver-order-form');
}

function deliverOnGet() {
  tblDeliverLine.refresh({
    id : deliverOrder.id
  });

  deliverLine.reset('deliver-line-form');
  if (deliverOrder.properties.status_id == 'DELIVER_NEW')
    $('#btRealizeOrder').show();

  else
    $('#btRealizeOrder').hide();

}

function deliverOnReset() {
  tblDeliverLine.refresh({
    id : deliverOrder.id
  });

  deliverLine.reset('deliver-line-form');
  $('#itAddress').val(0);
}

function btRealizeOrderOnClick() {
  if (deliverOrder.id == -1) {
    new DialogAlert('Wybierz awizacje dostawy')
    return;
  }

  var postData = {
    '_token' : getCSRFToken(),
    document_id : deliverOrder.id
  }

  $.post('realize-deliver', postData, function(res) {
    if (res.result === false)
      handleErrors(res.errors, 'deliver-order-form');
    else {
      tblDeliverOrder.refresh();
      $('#btRealizeOrder').hide();
    }

  });
}

// Linie awizacji

function btSaveDeliverLineOnClick() {
  if (deliverOrder.id == -1) {
    new DialogAlert('Wybierz awizacje dostawy')
    return;
  }

  var result = deliverLine.save('deliver-line-form');
}

function btNewDeliverLineOnClick() {
  if (deliverOrder.id == -1) {
    new DialogAlert('Wybierz awizacje dostawy')
    return;
  }
  deliverLine.reset('deliver-line-form');
}

function tblDeliverLineOnRowSelected(data) {
  deliverLine.get(data[0], 'deliver-line-form');
}

function btDeleteDeliverLineOnClick() {
  deliverLine.remove('deliver-line-form');
}

function deliverLineOnSave(result) {
  tblDeliverLine.refresh({
    id : deliverOrder.id
  });
}

function deliverLineOnRemove() {
  tblDeliverLine.refresh();
  deliverLine.properties['document_id'] = deliverOrder.id;
}

function deliverLineOnReset() {
  deliverLine.properties['document_id'] = deliverOrder.id;
}
