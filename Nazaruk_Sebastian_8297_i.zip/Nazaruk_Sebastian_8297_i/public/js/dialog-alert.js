function DialogAlert(msg, modal, onClose, title) {

  var id = parseInt(Math.random() * 1e+6);

  $('body')
      .append(
          '<div id="'
              + id
              + '"><span class="ui-icon ui-icon-alert" style="float: left; margin: 0 7px 20px 0;"></span>'
              + msg + '</div>');

  this.onOk = function(e) {
    $(this).dialog('close');
  }

  var buttons = new Object();
  buttons['OK'] = this.onOk;

  $('#' + id).dialog({
    resizable : false,
    title : title != null ? title : 'Komunikat',
    show : {
      effect : 'fade',
      duration : 150
    },
    hide : {
      effect : 'fade',
      duration : 150
    },
    modal : modal == null ? true : modal,
    buttons : buttons,
    close : function() {
      $(this).remove();

      if (onClose)
        onClose();
    }
  });
}