function isEmptyLogin() {
  var selector = $('#itLogin');

  return selector.val() == '';
}

function isEmptyPassword() {
  var selector = $('#itPassword');

  return selector.val() == '';
}

function clearErrors() {
  removeInputError('itLogin');
  removeInputError('itPassword');
}

function validateLoginData() {
  clearErrors();
  var result = true;
  if (isEmptyLogin()) {
    setInputError('itLogin', 'Wypełnij to pole');
    result = false;
  }

  if (isEmptyPassword()) {
    setInputError('itPassword', 'Wypełnij to pole');
    result = false;
  }

  return result;
}

function btLoginOnClick() {
  if (validateLoginData()) {
    var credentials = {
      '_token' : getCSRFToken(),
      login : $('#itLogin').val(),
      password : $('#itPassword').val()
    }

    $.post('login-user', credentials, function(data) {
      if (data.result)
        window.location.reload();
      else
        handleErrors(data.errors, 'login-form')

      console.log(data);
      // TODO obsługa niepoprawnego logwania
      $(".result").html(data);
    });
  }
}

$(document).ready(function() {
  $('#btLogin').click(btLoginOnClick);
});