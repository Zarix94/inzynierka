var user = new ModelObject('User');

function initialize() {
  tblUserData = {
    id : 'tblUser',
    adapter : 'UserDTAdapter'
  };

  window['tblUser'] = new DataTableObj(tblUserData);
  tblUser.init();

  $('#btSave').click(btSaveOnClick);
  $('#btNew').click(btNewOnClick);
  $('#btDelete').click(btDeleteOnClick);
  $('#btCloseDialog').click(function() {
    $('#setPasswordDialog').hide();
  });

  $('#btSetPasswordDialog').click(function() {
    if (user.id > 0) {
      $('#itPassword').val('');
      $('#setPasswordDialog').css('display', 'flex');
    } else
      new DialogAlert('Wybierz użytkownika');
  });

  $('#btSetPassword').click(function() {
    var postData = {
      '_token' : getCSRFToken(),
      'user-id' : user.id,
      'password' : $('#itPassword').val()
    }

    $.post('set-password', postData, function(data) {
      if (data.result === false)
        handleErrors(data.errors, 'change-password-form');
      else if (self.onSaveFunction !== null) {
        new DialogAlert('Zmienion hasło użytkownika');
        clearErrors('change-password-form');
        $('#setPasswordDialog').hide();
      }
    });

  });
}

function userOnSave(result) {
  tblUser.refresh();
}

function loadComplete() {
  initialize();

  user.onSaveFunction = userOnSave;
  user.onRemoveFunction = userOnSave;
}

function btSaveOnClick() {
  var result = user.save('user-form');

}

function btNewOnClick() {
  user.reset('user-form');
}

function tblUserOnRowSelected(data) {
  user.get(data[0], 'user-form');
}

function btDeleteOnClick() {
  user.remove('user-form');
}