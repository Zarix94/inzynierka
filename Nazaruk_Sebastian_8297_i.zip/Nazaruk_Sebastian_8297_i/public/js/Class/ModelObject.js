class ModelObject {
  constructor(type) {
    this.properties = {};
    this.id = -1;
    this.type = type;
    this.onSaveFunction = null;
    this.onRemoveFunction = null;
    this.onGet = null;
    this.onReset = null;

  }
    
  getProperties(formId){
    var tmpProp = this.properties;
    
    $('#' + formId + ' .form-control').each(function(idx, elm) {
      var propName = $(elm).attr('data-id');
      var propValue = $(elm).val();

      if(typeof(tmpProp) === 'undefined')
        tmpProp = {};
      
      tmpProp[propName] = propValue;

    });
    
    this.properties = tmpProp;
  }
  
  save(formId){
    this.getProperties(formId)
    var postData = {
      '_token' : getCSRFToken(),
      object: this
    }
    
    var self = this;

    $.post('save-object', postData, function(data) {
      if(data.result === false)
        handleErrors(data.errors, formId); 
      else if(self.onSaveFunction !== null){
        clearErrors(formId);
        new DialogAlert('Zapisano');
        self.onSaveFunction(data);}
    });

  }
  
  reset(formId){
    var postData = {
        '_token' : getCSRFToken(),
        'type': this.type
      }
    
    var self = this;
    
    $.post('reset-object', postData, function(data) {
      
      data.data.fields.forEach(function(elm){
        var selector = $('#' + formId + ' .form-control[data-id="'+elm+'"]');
        
        if(selector.is('select'))
          selector.val(0);
        else
          selector.val('');
        
        selector.removeClass('is-invalid');
      });
      
      self.id = -1;
      self.properties = {};
      if(self.onReset !== null)
        self.onReset();
    });
  }
  
  setId(id){
    this.id = id;
  }
  
  get(objectId, formId){
    var postData = {
        '_token' : getCSRFToken(),
        'type': this.type,
        'id': objectId
      }
    
    var self = this;
   
    $.post('get-object', postData, function(res) {
      if(res.result){
        for (const [key, value] of Object.entries(res.data.obj[0])) {
          if(key === 'id')
            self.setId(value);
          else {
            var selector = $('#' + formId + ' .form-control[data-id="'+key+'"]');
            selector.val(value);
            self.properties[key] = value;
          }
        }
        
        if(self.onGet !== null)
          self.onGet();
       }
    });
  }
  
  remove(formId){
    if(this.id < 1)
      return;
    
    var self = this;
    
    new DialogAlertConfirm('Czy usunąć? Tej operacji nie będzie można cofnąć', function(){
      var postData = {
          '_token' : getCSRFToken(),
          'type': self.type,
          'id': self.id
        }
        
      $.post('remove-object', postData, function(res) {
        if(res.result === true && self.onRemoveFunction !== null)
            self.onRemoveFunction(res);
      });
    });
    
    
  }
  
}