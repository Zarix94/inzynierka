@extends('template') @section('page-head')
<script type="text/javascript" src="js/warehouse.js"></script>
@endsection
@section('filter-content')
  {!! $components['filters'] !!}
@endsection

@section('page-content')
  {!! $dataTables['tblWarehouse'] !!}
    <div id="tabs-warehouse" style="height: 350px">
    <ul>
      <li><a href="#tab-data">Dane</a></li>
      <li><a href="#tab-inventory">Stany magazynowe</a></li>
    </ul>
    <div id="tab-data" style="display: flex">
      {!! $components['warehouse-data'] !!}
    </div>
    <div id="tab-inventory" style="display: flex">
      {!! $dataTables['tblWarehouseInventory'] !!}
    </div>

  </div>

@endsection
