<div style="width: 100%">
  {!! $dataTables['tblStatus'] !!}
</div>
<div style="display: flex">
  {!! $components['status-data'] !!}
</div>
