@extends('layout')
@section('head')
  <link rel="stylesheet" href="http://cdn.datatables.net/1.10.23/css/jquery.dataTables.min.css" />
  <script type="text/javascript" src="http://cdn.datatables.net/1.10.23/js/jquery.dataTables.min.js"></script>
  <script type="text/javascript" src="js/navigation-menu.js"></script>
  <script type="text/javascript" src="js/app-datatable.js"></script>
  <script type="text/javascript" src="js/Class/ModelObject.js"></script>
  <script type="text/javascript" src="js/dialog-alert.js"></script>
  <script type="text/javascript" src="js/dialog-alert-confirm.js"></script>
  @yield('page-head')
@endsection

@section('content')
<div class="container  mw-100 p-0 h-100">
  @include('menu')
  <div id="content-holder">
    @include('filter')
    <div id="content-panel" class="border-start">
      @yield('page-content')
    </div>
  </div>
</div>
@endsection