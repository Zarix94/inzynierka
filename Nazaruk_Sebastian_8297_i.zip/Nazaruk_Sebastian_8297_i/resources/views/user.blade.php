@extends('template') @section('page-head')
<script type="text/javascript" src="js/user.js"></script>
@endsection
@section('page-content')
  {!! $dataTables['tblUser'] !!}
  <div style="display: flex">
    {!! $components['user-data'] !!}
  </div>

  <div id="setPasswordDialog" style="display: none; position: absolute; width: 100%; height: 100%; background: #0000008f; top: 0; left: 0;">
    <div style="width: 500px; margin: auto;">
        {!! $components['set-password'] !!}
    </div>
  </div>
@endsection
