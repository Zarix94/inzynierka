<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf_token" content="{{ csrf_token() }}" />

        <title>System do zarządzania magazynem</title>

        <!-- Fonts -->
          <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap" />
          <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons" />
       <!-- Styles -->
       <link rel="stylesheet" type="text/css" href="{{ asset('/css/normalize.css') }}" />
       <link rel="stylesheet" type="text/css" href="{{ asset('/css/layout.css') }}" />
       <link rel="stylesheet" type="text/css" href="css/app.css"/>

       <!-- JS-->
       <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
       <script type="text/javascript" src="js/app.js"></script>
       <script type="text/javascript" src="js/main.js"></script>

       @yield('head')

    </head>
    <body class="antialiased">
        @yield('content')
    </body>


</html>
