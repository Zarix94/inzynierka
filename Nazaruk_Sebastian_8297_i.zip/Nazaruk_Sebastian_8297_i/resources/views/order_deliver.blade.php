<div style="width: 100%">
  {!! $dataTables['tblDeliverOrder'] !!}
</div>
 <div id="tabs-deliver_order" style="height: 350px">
    <ul>
      <li><a href="#deliver-order-data">Dane</a></li>
      <li><a href="#deliver-order-line">Linie</a></li>
      <li><a href="#deliver-order-add">Dodaj linie</a></li>

    </ul>
    <div id="deliver-order-data" style="display: flex">
      {!! $components['order-data'] !!}
    </div>
    <div id="deliver-order-line" style="display: flex">
      {!! $dataTables['tblDeliverLine'] !!}
    </div>
    <div id="deliver-order-add" style="display: flex">
      {!! $components['order-line-data'] !!}
    </div>
  </div>