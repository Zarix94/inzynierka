@extends('layout')
@section('head')
  <script type="text/javascript" src="js/login.js"></script>
@endsection
@section('content')
<div class="container h-100">
  <div class="row h-100 justify-content-center align-items-center">
    <form id="login-form" class="col-3 border border-primary rounded-top"  style="padding: 10px; background: #fff">
      <p class="text-center text-uppercase fs-4 text-secondary">System do zarządzania wirtualnym magazynem</p>
      <p class="text-start fs-6 text-secondary" style="margin: 0px">Zaloguj się:</p>
      <div class="form-group form-floating  mb-3">
        <input id="itLogin" type="text" class="form-control" data-id='login' placeholder="Login">
        <label for="itLogin">Login</label>
        <div id="itLogin-invalid-msg" data-invalidnumber="6" class="invalid-feedback">.</div>
      </div>
      <div class="form-group form-floating">
        <input id="itPassword" type="password" class="form-control" data-id='password' placeholder="Hasło">
        <label for="itPassword">Hasło</label>
        <div id="itPassword-invalid-msg"class="invalid-feedback"></div>
      </div>
      <div class="container" style="margin-top: 20px; padding:0px">
        <div class="row align-items-start " >
          <div class="col ">
            <p style="margin-top: 5px;"><a href="password-recovery">Przypomnienie hasła</a></p>
          </div>
          <div class="col">
            <div style="float: right">
              <button id="btLogin" type="button" style="width: 100px; color: #fff" class="btn btn-primary">Zaloguj</button>
            </div>
          </div>
        </div>
      </div>
    </form>
  </div>
</div>
@endsection