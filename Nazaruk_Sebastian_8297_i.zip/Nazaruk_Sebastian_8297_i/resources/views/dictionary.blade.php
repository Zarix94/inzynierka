@extends('template') @section('page-head')
<script type="text/javascript" src="js/dictionary.js"></script>
@endsection
@section('page-content')
  <div id="tabs-dictionary" style="height: calc(100% - 40px)">
    <ul>
      <li><a href="#tabCountry">Kraje</a></li>
      <li><a href="#tabSkuUnit">Jednostki składowania</a></li>
      <li><a href="#tabSkuCondition">Kondycje towarów</a></li>
      <li><a href="#tabCarrier">Przewoźnicy</a></li>
      <li><a href="#tabStatus">Statusy</a></li>

    </ul>
    <div id="tabCountry">
       @include('dict_country')
    </div>
    <div id="tabSkuUnit">
       @include('dict_sku_unit')
    </div>
    <div id="tabSkuCondition">
      @include('dict_sku_condition')
    </div>
    <div id="tabCarrier">
      @include('dict_carrier')
    </div>
    <div id="tabStatus">
      @include('dict_status')
    </div>
  </div>
@endsection
