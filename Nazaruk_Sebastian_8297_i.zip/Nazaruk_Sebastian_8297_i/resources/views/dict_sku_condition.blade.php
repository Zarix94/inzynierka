<div style="width: 100%">
  {!! $dataTables['tblSkuCondition'] !!}
</div>
<div style="display: flex">
  {!! $components['sku-condition-data'] !!}
</div>
