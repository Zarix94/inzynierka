<div style="width: 100%">
  {!! $dataTables['tblCarrier'] !!}
</div>
<div style="display: flex">
  {!! $components['carrier-data'] !!}
</div>
