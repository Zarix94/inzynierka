<nav class="container mw-100 p-0 navigation-holder" >
  @php
    $bookmarks = [
      'people'=> ['label'=> 'Klienci', 'target'=> 'client'],
      'home_work'=>['label'=> 'Magazyny', 'target'=> 'warehouse'],
      'folder_open'=> ['label'=> 'Produkty', 'target'=> 'product'],
      'business_center'=> ['label'=> 'Adresy', 'target'=> 'address'],
      'article'=> ['label'=> 'Dokumenty', 'target'=> 'order'],
      'query_stats'=> ['label'=> 'Raporty', 'target'=> 'report'],
      'menu_book'=> ['label'=> 'Słowniki', 'target'=> 'dictionary'],
      'group'=> ['label'=> 'Użytkownicy', 'target'=> 'user'],
    ];
  @endphp
  @foreach ($bookmarks as $icon => $bookmark)
    @php
      $user = Auth::user();
      if($user->isClientUser())
        if($bookmark['target'] == 'client' || $bookmark['target'] ==  'user')
          continue;

      if(!$user->isSystemAdmin())
        if($bookmark['target'] == 'dictionary')
          continue;


      $class = '';
      if($view === $bookmark['target'])
        $class = 'current-tab';
    @endphp

    <div class="nav-elm {{ $class }}" data-target="{{ $bookmark['target'] }}">
      <span class="material-icons md-36">{{ $icon }}</span>
      <p>{{ $bookmark['label'] }}</p>
    </div>
  @endforeach

  <div class=" nav-elm" data-target="logout" style="position: absolute; right: 0;">
    <span class="material-icons md-36">logout</span>
    <p>Wyloguj</p>
  </div>
</nav>
