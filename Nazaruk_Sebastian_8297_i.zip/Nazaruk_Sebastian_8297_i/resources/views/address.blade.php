@extends('template') @section('page-head')
<script type="text/javascript" src="js/address.js"></script>
@endsection
@section('page-content')
  {!! $dataTables['tblAddress'] !!}
  <div style="display: flex">
    {!! $components['address-data'] !!}
  </div>

@endsection
