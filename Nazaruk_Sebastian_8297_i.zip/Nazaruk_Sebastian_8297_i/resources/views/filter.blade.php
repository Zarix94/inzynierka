<div id="filter-menu" class="border-end ">
  <div class="text-center">
    <span id="filter-icon" class="material-icons md-36">search</span>
    <span id="filter-title">Wyszukiwanie</span>
  </div>
  <div style="margin-bottom: 10px;">@yield('filter-content')</div>
  <div class="text-center">
    <button id="clearFilter" type="button" class="btn btn-secondary">Wyczyść</button>
    <button id="applyFilter" type="button" class="btn btn-secondary">Wyszukaj</button>
  </div>
</div>