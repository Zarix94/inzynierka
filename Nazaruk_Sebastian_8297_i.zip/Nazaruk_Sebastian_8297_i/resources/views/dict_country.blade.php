
<div style="width: 100%">
  {!! $dataTables['tblCountry'] !!}
</div>
<div style="display: flex">
  {!! $components['country-data'] !!}
</div>
