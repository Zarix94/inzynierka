@extends('template') @section('page-head')
<script type="text/javascript" src="js/product.js"></script>
@endsection

@section('filter-content')
  {!! $components['filters'] !!}
@endsection

@section('page-content')
  {!! $dataTables['tblProduct'] !!}
  <div id="tabs-product" style="height: 350px">
    <ul>
      <li><a href="#tab-data">Dane</a></li>
      <li><a href="#tab-inventory-details">Szczegółowe stany</a></li>
    </ul>
    <div id="tab-data" style="display: flex">
      {!! $components['tab-data'] !!}
    </div>
    <div id="tab-inventory-details">
      {!! $dataTables['tblProductInventory'] !!}
    </div>
  </div>

@endsection
