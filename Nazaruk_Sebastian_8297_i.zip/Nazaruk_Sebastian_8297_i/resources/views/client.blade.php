@extends('template') @section('page-head')
<script type="text/javascript" src="js/client.js"></script>

@section('filter-content')
  {!! $components['filters'] !!}
@endsection

@section('page-content')
  {!! $dataTables['tblClient'] !!}
  <div id="tabs-client" style="height: 350px">
    <ul>
      <li><a href="#tab-data">Dane</a></li>
      <li><a href="#fragment-2">Magazyny</a></li>
      <li><a href="#fragment-3">Kondycje towarów</a></li>
      <li><a href="#fragment-4">Przewoźnicy</a></li>
    </ul>
    <div id="tab-data" style="display: flex">
      {!! $components['tab-data'] !!}
    </div>
    <div id="fragment-2" style="display: flex">
      <div style="width: 1500px">
        {!! $dataTables['tblClientWarehouse'] !!}
      </div>
      <div>
        {!! $components['assign-warehouse-button'] !!}
      </div>
    </div>
    <div id="fragment-3" style="display: flex">
      <div style="width: 1500px">
        {!! $dataTables['tblClientSkuCondition'] !!}
      </div>
      <div>
        {!! $components['assign-condition-button'] !!}
      </div>
    </div>
    <div id="fragment-4" style="display: flex">
      <div style="width: 1500px">
        {!! $dataTables['tblClientCarrier'] !!}
      </div>
      <div>
        {!! $components['assign-carrier-button'] !!}
      </div>
    </div>
  </div>
@endsection
