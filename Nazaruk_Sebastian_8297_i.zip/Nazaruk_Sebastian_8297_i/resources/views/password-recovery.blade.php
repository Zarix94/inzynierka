@extends('layout')

@section('content')
<div class="container h-100">
  <div class="row h-100 justify-content-center align-items-center">
    <form class="col-3 border border-primary rounded-top"  style="padding: 10px; background: #fff">
      <p class="text-center text-uppercase fs-4 text-secondary">System do zarządzania wirtualnym magazynem</p>
      <p class="text-start fs-6 text-secondary" style="margin: 0px">Przypomnienie hasła:</p>
      <div class="form-group form-floating  mb-3">
        <input id="itEmailAddress" type="email" class="form-control"  placeholder="Adres e-mail" required>
        <label for="itEmailAddress">Adres e-mail</label>
      </div>
      <div class="form-group form-floating  mb-3">
        <input id="itRepeatEmailAddress" type="email" class="form-control"  placeholder="Powtórz adres e-mail" required>
        <label for="itRepeatEmailAddress">Powtórz adres e-mail</label>
      </div>
      <div style="float: right">
        <button  type="button" style="width: 150px; color: #fff" class="btn btn-primary">Przypomnij hasło</button>
      </div>
    </form>
  </div>
</div>
@endsection