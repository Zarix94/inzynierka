<div style="width: 100%">
  {!! $dataTables['tblSkuUnit'] !!}
</div>
<div style="display: flex">
  {!! $components['sku-unit-data'] !!}
</div>
