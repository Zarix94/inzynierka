@extends('template') @section('page-head')
<script type="text/javascript" src="js/deliver-order.js"></script>

@endsection
@section('page-content')
  <div id="tabs-order" style="height: calc(100% - 50px)">
    <ul>
      <li><a href="#deliver-order">Awizacje dostaw</a></li>
      <li><a href="#shipping-order">Awizacje wysyłki</a></li>
    </ul>
    <div id="deliver-order">
      @include('order_deliver')
    </div>
    <div id="shipping-order" style="display: flex">
      <div style="width: 1500px">
      </div>
      <div>
      </div>
    </div>

  </div>
@endsection
